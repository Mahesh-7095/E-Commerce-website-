import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const AuthPage = () => {
  const navigate = useNavigate();
  const { login, signup } = useAuth();
  const location = useLocation();

  const [view, setView] = useState(
    location.pathname === '/login' ? 'login' : 'signup'
  );

  const [user, setUser] = useState({
    fullName: '', email: '', phone: '', password: '', confirmPassword: '',
  });

  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // FIX 1: was `const [ setFocused] = useState('')` — missing state variable name
  const [focused, setFocused] = useState('');

  // FIX 2: Separate password visibility for signup and login
  const [showSignupPassword, setShowSignupPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  const handleUserChange = (e) => setUser({ ...user, [e.target.name]: e.target.value });
  const handleLoginChange = (e) => setLoginForm({ ...loginForm, [e.target.name]: e.target.value });

  const switchTo = (v) => {
    setError('');
    setView(v);
  };

  // ── LOGIN SUBMIT ──
  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const data = await login(loginForm.email, loginForm.password);
      if (data.role === 'ADMIN') navigate('/admin-home');
      else navigate('/user-home');
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  // ── SIGNUP SUBMIT ──
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (user.password !== user.confirmPassword) { setError('Passwords do not match.'); return; }
    const digitsOnly = user.phone.replace(/\D/g, '');
    if (digitsOnly.length !== 10) { setError('Phone number must be exactly 10 digits.'); return; }
    setLoading(true);
    try {
      const res = await signup({ fullName: user.fullName, email: user.email, phone: user.phone, password: user.password });
      if (res.success) {
        alert(res.message || 'Account created! Please login.');
        switchTo('login');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Signup failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  /* SVG Icons */
  const UserIcon = () => (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>);
  const EmailIcon = () => (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>);
  const PhoneIcon = () => (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.62 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.53 1h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.1a16 16 0 0 0 6 6l.81-.81a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 21.73 16z"/></svg>);
  const LockIcon = () => (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>);
  const EyeIcon = () => (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>);
  const EyeOffIcon = () => (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>);

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;600&family=DM+Sans:wght@300;400;500&display=swap');
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        .auth-page {
          min-height: 100vh;
          display: flex;
          font-family: 'DM Sans', sans-serif;
          background: #050810;
          overflow: hidden;
        }
        /* ── LEFT PANEL ── */
        .signup-left {
          flex: 1;
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
        }
        .signup-left img { width: 100%; height: 100%; object-fit: cover; display: block; }
        .left-overlay {
          position: absolute; bottom: 48px; left: 44px; z-index: 2; color: #18b05d;
        }
        .left-overlay h1 {
          font-family: 'Cormorant Garamond', serif; font-size: 42px; font-weight: 300;
          letter-spacing: 0.03em; line-height: 1.15; text-shadow: 0 2px 20px rgba(0,0,0,0.5);
        }
        .left-overlay p {
          font-size: 14px; font-weight: 300; color: rgba(255,255,255,0.65);
          margin-top: 8px; letter-spacing: 0.06em; text-transform: uppercase;
        }
        /* ── RIGHT PANEL ── */
        .auth-right {
          width: 480px; min-height: 100vh; display: flex; justify-content: center;
          align-items: center; background: #ffffff; position: relative;
          flex-shrink: 0; padding: 32px 24px;
        }
        .auth-right::before, .auth-right::after {
          content: ''; position: absolute; border-radius: 50%; filter: blur(80px);
          animation: drift 8s ease-in-out infinite alternate; pointer-events: none;
        }
        .auth-right::before {
          width: 300px; height: 300px;
          background: radial-gradient(circle, rgba(20,182,23,0.18) 0%, transparent 70%);
          top: -80px; left: -60px;
        }
        .auth-right::after {
          width: 280px; height: 280px;
          background: radial-gradient(circle, rgba(138,43,226,0.15) 0%, transparent 70%);
          bottom: -60px; right: -40px; animation-delay: -4s;
        }
        .orb-mid {
          position: absolute; width: 200px; height: 200px; border-radius: 50%;
          background: radial-gradient(circle, rgba(0,255,180,0.08) 0%, transparent 70%);
          filter: blur(60px); top: 50%; left: 50%; transform: translate(-50%,-50%);
          animation: pulse 6s ease-in-out infinite; pointer-events: none;
        }
        .grid-overlay {
          position: absolute; inset: 0;
          background-image: linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px);
          background-size: 48px 48px; pointer-events: none;
        }
        /* ── CARD SCENE (flip container) ── */
        .card-scene {
          position: relative; width: 100%; max-width: 400px;
          perspective: 1200px; z-index: 10;
        }
        .card-flipper {
          position: relative; width: 100%;
          transition: transform 0.6s cubic-bezier(0.16,1,0.3,1);
          transform-style: preserve-3d;
        }
        .card-face {
          width: 100%;
          backface-visibility: hidden;
          -webkit-backface-visibility: hidden;
          border-radius: 24px;
          background: rgba(14,17,21,0.95);
          backdrop-filter: blur(24px);
          border: 1px solid rgba(255,255,255,0.1);
          box-shadow: 0 0 0 1px rgba(79,195,247,0.08), 0 30px 80px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.1);
          padding: 44px 40px 36px;
        }
        .card-face--back {
          position: absolute;
          top: 0; left: 0;
          transform: rotateY(180deg);
        }
        .card-flipper.flipped {
          transform: rotateY(180deg);
        }
        @keyframes drift {
          0% { transform: translate(0,0) scale(1); }
          100% { transform: translate(20px,15px) scale(1.05); }
        }
        @keyframes pulse {
          0%,100% { opacity:0.5; transform:translate(-50%,-50%) scale(1); }
          50% { opacity:1; transform:translate(-50%,-50%) scale(1.1); }
        }
        .accent-bar {
          width: 48px; height: 3px;
          background: linear-gradient(90deg,#4fc3f7,#a78bfa);
          border-radius: 99px; margin: 0 auto 20px;
        }
        .auth-title {
          font-family: 'Cormorant Garamond', serif; font-size: 32px; font-weight: 300;
          letter-spacing: 0.04em; color: #f0f4ff; text-align: center; margin-bottom: 6px;
        }
        .auth-sub {
          font-size: 12px; font-weight: 300; color: rgba(255,255,255,0.35);
          text-align: center; letter-spacing: 0.12em; text-transform: uppercase; margin-bottom: 30px;
        }
        .error-box {
          display: flex; align-items: center; gap: 10px;
          background: rgba(255,90,90,0.1); border: 1px solid rgba(255,90,90,0.25);
          color: #ff8a8a; padding: 11px 14px; border-radius: 10px;
          margin-bottom: 20px; font-size: 13px; animation: shakeIn 0.4s ease;
        }
        @keyframes shakeIn {
          0%,100% { transform: translateX(0); } 25% { transform: translateX(-6px); } 75% { transform: translateX(6px); }
        }
        .input-wrap { position: relative; margin-bottom: 14px; }
        .input-icon {
          position: absolute; left: 13px; top: 50%; transform: translateY(-50%);
          color: rgba(79,195,247,0.5); transition: color 0.2s; pointer-events: none;
          display: flex; align-items: center; line-height: 1;
        }
        .input-wrap:focus-within .input-icon { color: #4fc3f7; }
        .eye-toggle {
          position: absolute; right: 12px; top: 50%; transform: translateY(-50%);
          background: none; border: none; cursor: pointer; color: rgba(255,255,255,0.3);
          display: flex; align-items: center; padding: 2px; transition: color 0.2s;
        }
        .eye-toggle:hover { color: #4fc3f7; }
        .auth-input {
          width: 100%; padding: 13px 14px 13px 38px;
          background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1);
          border-radius: 10px; color: #e8eeff; font-size: 14px;
          font-family: 'DM Sans', sans-serif; font-weight: 300; outline: none;
          transition: border-color 0.25s, background 0.25s, box-shadow 0.25s;
        }
        .auth-input.has-eye { padding-right: 40px; }
        .auth-input::placeholder { color: rgba(255,255,255,0.25); }
        .auth-input:focus {
          border-color: rgba(79,195,247,0.5); background: rgba(79,195,247,0.06);
          box-shadow: 0 0 0 3px rgba(79,195,247,0.08), inset 0 0 20px rgba(79,195,247,0.03);
        }
        .auth-input:-webkit-autofill, .auth-input:-webkit-autofill:focus {
          -webkit-box-shadow: 0 0 0 1000px #0d1425 inset; -webkit-text-fill-color: #e8eeff;
        }
        .phone-wrap { display: flex; gap: 8px; margin-bottom: 14px; }
        .phone-input-wrap { flex: 1; position: relative; }
        .phone-input-icon {
          position: absolute; left: 13px; top: 50%; transform: translateY(-50%);
          color: rgba(79,195,247,0.5); pointer-events: none; display: flex; align-items: center; transition: color 0.2s;
        }
        .phone-input-wrap:focus-within .phone-input-icon { color: #4fc3f7; }
        .auth-btn {
          position: relative; width: 100%; padding: 14px; margin-top: 8px;
          background: linear-gradient(135deg,#1565c0,#4fc3f7 60%,#a78bfa);
          background-size: 200% 200%; color: #fff; border: none; border-radius: 10px;
          cursor: pointer; font-size: 14px; font-family: 'DM Sans', sans-serif; font-weight: 500;
          letter-spacing: 0.08em; text-transform: uppercase; overflow: hidden;
          transition: opacity 0.2s, transform 0.15s, box-shadow 0.2s;
          box-shadow: 0 4px 24px rgba(79,195,247,0.2); animation: gradShift 4s ease infinite;
        }
        @keyframes gradShift {
          0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; }
        }
        .auth-btn::before {
          content: ''; position: absolute; inset: 0;
          background: linear-gradient(135deg,rgba(255,255,255,0.15),transparent);
          opacity: 0; transition: opacity 0.25s;
        }
        .auth-btn:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 8px 32px rgba(79,195,247,0.35); }
        .auth-btn:hover:not(:disabled)::before { opacity: 1; }
        .auth-btn:active:not(:disabled) { transform: translateY(0); }
        .auth-btn:disabled { opacity: 0.55; cursor: not-allowed; }
        .spinner {
          display: inline-block; width: 14px; height: 14px;
          border: 2px solid rgba(255,255,255,0.3); border-top-color: #fff;
          border-radius: 50%; animation: spin 0.7s linear infinite;
          vertical-align: middle; margin-right: 8px;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        .divider {
          display: flex; align-items: center; gap: 12px; margin: 22px 0 18px;
          color: rgba(255,255,255,0.15); font-size: 11px; letter-spacing: 0.1em;
        }
        .divider::before, .divider::after { content: ''; flex: 1; height: 1px; background: rgba(255,255,255,0.08); }
        .switch-text {
          text-align: center; font-size: 13px; color: rgba(255,255,255,0.35);
        }
        .switch-text button {
          background: none; border: none; color: #4fc3f7; cursor: pointer;
          font-weight: 500; font-size: 13px; font-family: 'DM Sans', sans-serif;
          padding: 0; transition: color 0.2s;
        }
        .switch-text button:hover { color: #a78bfa; }
        @media (max-width: 820px) {
          .signup-left { display: none; }
          .auth-right { width: 100%; }
        }
      `}</style>

      <div className="auth-page">
        {/* LEFT */}
        <div className="signup-left">
          <img src="ecommerce.png" alt="E-Commerce" />
          <div className="left-overlay">
            <h1>Shop the<br />Future Today</h1>
            <p>Thousands of products · Best deals</p>
          </div>
        </div>

        {/* RIGHT */}
        <div className="auth-right">
          <div className="grid-overlay" />
          <div className="orb-mid" />
          <div className="card-scene">
            <div className={`card-flipper ${view === 'login' ? 'flipped' : ''}`}>

              {/* ── FRONT: SIGNUP ── */}
              <div className="card-face card-face--front">
                <div className="accent-bar" />
                <h2 className="auth-title">Create Account</h2>
                <p className="auth-sub">Join us today — it's free</p>
                {error && view === 'signup' && (
                  <div className="error-box"><span>⚠</span> {error}</div>
                )}
                <form onSubmit={handleSubmit}>
                  <div className="input-wrap">
                    <span className="input-icon"><UserIcon /></span>
                    <input className="auth-input" type="text" name="fullName" placeholder="Full Name"
                      value={user.fullName} onChange={handleUserChange}
                      onFocus={() => setFocused('fullName')} onBlur={() => setFocused('')} required />
                  </div>
                  <div className="input-wrap">
                    <span className="input-icon"><EmailIcon /></span>
                    <input className="auth-input" type="email" name="email" placeholder="Email Address"
                      value={user.email} onChange={handleUserChange}
                      onFocus={() => setFocused('email')} onBlur={() => setFocused('')} required />
                  </div>
                  <div className="phone-wrap">
                    <div className="phone-input-wrap">
                      <span className="phone-input-icon"><PhoneIcon /></span>
                      <input className="auth-input" type="tel" name="phone" placeholder="Phone Number (10 digits)"
                        value={user.phone}
                        onChange={(e) => { const val = e.target.value.replace(/\D/g,'').slice(0,10); setUser({...user, phone: val}); }}
                        onFocus={() => setFocused('phone')} onBlur={() => setFocused('')}
                        maxLength={10} required />
                    </div>
                  </div>
                  {/* FIX 2: Use showSignupPassword instead of shared showPassword */}
                  <div className="input-wrap">
                    <span className="input-icon"><LockIcon /></span>
                    <input className="auth-input has-eye" type={showSignupPassword ? 'text' : 'password'}
                      name="password" placeholder="Password" value={user.password}
                      onChange={handleUserChange} onFocus={() => setFocused('password')} onBlur={() => setFocused('')} required />
                    <button type="button" className="eye-toggle" onClick={() => setShowSignupPassword(p => !p)} tabIndex={-1}>
                      {showSignupPassword ? <EyeOffIcon /> : <EyeIcon />}
                    </button>
                  </div>
                  <div className="input-wrap">
                    <span className="input-icon"><LockIcon /></span>
                    <input className="auth-input has-eye" type={showConfirmPassword ? 'text' : 'password'}
                      name="confirmPassword" placeholder="Confirm Password" value={user.confirmPassword}
                      onChange={handleUserChange} onFocus={() => setFocused('confirmPassword')} onBlur={() => setFocused('')} required />
                    <button type="button" className="eye-toggle" onClick={() => setShowConfirmPassword(p => !p)} tabIndex={-1}>
                      {showConfirmPassword ? <EyeOffIcon /> : <EyeIcon />}
                    </button>
                  </div>
                  <button type="submit" disabled={loading} className="auth-btn">
                    {loading && <span className="spinner" />}
                    {loading ? 'Registering...' : 'Create Account'}
                  </button>
                </form>
                <div className="divider">or</div>
                <p className="switch-text">
                  Already have an account? <button onClick={() => switchTo('login')}>Sign in</button>
                </p>
              </div>

              {/* ── BACK: LOGIN ── */}
              <div className="card-face card-face--back">
                <div className="accent-bar" />
                <h2 className="auth-title">Login</h2>
                <p className="auth-sub">Welcome back</p>
                {error && view === 'login' && (
                  <div className="error-box"><span>⚠</span> {error}</div>
                )}
                <form onSubmit={handleLogin}>
                  <div className="input-wrap">
                    <span className="input-icon"><EmailIcon /></span>
                    <input className="auth-input" type="email" name="email" placeholder="Email"
                      value={loginForm.email} onChange={handleLoginChange} required />
                  </div>
                  {/* FIX 2: Use showLoginPassword instead of shared showPassword */}
                  <div className="input-wrap">
                    <span className="input-icon"><LockIcon /></span>
                    <input className="auth-input has-eye" type={showLoginPassword ? 'text' : 'password'}
                      name="password" placeholder="Password"
                      value={loginForm.password} onChange={handleLoginChange} required />
                    <button type="button" className="eye-toggle" onClick={() => setShowLoginPassword(p => !p)} tabIndex={-1}>
                      {showLoginPassword ? <EyeOffIcon /> : <EyeIcon />}
                    </button>
                  </div>
                  <button type="submit" disabled={loading} className="auth-btn">
                    {loading && <span className="spinner" />}
                    {loading ? 'Logging in...' : 'Login'}
                  </button>
                </form>
                <div className="divider">or</div>
                <p className="switch-text">
                  Don't have an account? <button onClick={() => switchTo('signup')}>Sign up</button>
                </p>
              </div>

            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AuthPage;