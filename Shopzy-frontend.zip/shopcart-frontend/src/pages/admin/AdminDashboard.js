import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../services/api';
import { useAuth } from '../../context/AuthContext';

// ─── Inject Global Styles ────────────────────────────────────────────────────
const injectStyles = () => {
  if (document.getElementById('adm-styles')) return;
  const el = document.createElement('style');
  el.id = 'adm-styles';
  el.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fraunces:wght@700;900&display=swap');

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    @keyframes adm-spin   { to { transform: rotate(360deg); } }
    @keyframes adm-fadeUp { from { opacity:0; transform:translateY(18px); } to { opacity:1; transform:translateY(0); } }
    @keyframes adm-pop    { 0%{transform:scale(0.94);opacity:0} 100%{transform:scale(1);opacity:1} }

    /* ── Topbar ── */
    .adm-topbar {
      position: sticky; top: 0; z-index: 200;
      display: flex; justify-content: space-between; align-items: center;
      padding: 0 40px; height: 68px;
      background: rgba(255,255,255,0.88);
      backdrop-filter: blur(18px);
      border-bottom: 1px solid #ede9fe;
      box-shadow: 0 2px 24px rgba(99,102,241,0.07);
    }
    .adm-brand {
      display: flex; align-items: center; gap: 12px;
    }
    .adm-brand-icon {
      width: 38px; height: 38px; border-radius: 11px;
      background: linear-gradient(135deg,#6366f1,#8b5cf6);
      display: flex; align-items: center; justify-content: center;
      font-size: 18px; box-shadow: 0 4px 14px rgba(99,102,241,0.38);
    }
    .adm-brand-name {
      font-family: 'Fraunces', serif;
      font-size: 21px; font-weight: 900;
      background: linear-gradient(135deg,#6366f1,#8b5cf6);
      -webkit-background-clip: text; -webkit-text-fill-color: transparent;
      letter-spacing: -0.02em;
    }

    /* ── Buttons ── */
    .adm-btn {
      font-family: 'Plus Jakarta Sans', sans-serif;
      font-weight: 600; font-size: 13px;
      border: none; border-radius: 12px;
      cursor: pointer; padding: 10px 20px;
      transition: all 0.22s cubic-bezier(.4,0,.2,1);
      letter-spacing: 0.01em;
      display: inline-flex; align-items: center; gap: 6px;
    }
    .adm-btn:hover  { transform: translateY(-2px); }
    .adm-btn:active { transform: translateY(0) scale(0.98); }

    .adm-btn-violet {
      background: linear-gradient(135deg,#6366f1,#8b5cf6);
      color: #fff;
      box-shadow: 0 4px 14px rgba(99,102,241,0.35);
    }
    .adm-btn-violet:hover { box-shadow: 0 8px 24px rgba(99,102,241,0.45); }

    .adm-btn-amber {
      background: linear-gradient(135deg,#f59e0b,#d97706);
      color: #fff;
      box-shadow: 0 4px 14px rgba(245,158,11,0.3);
    }
    .adm-btn-amber:hover { box-shadow: 0 8px 22px rgba(245,158,11,0.4); }

    .adm-btn-red {
      background: linear-gradient(135deg,#f43f5e,#e11d48);
      color: #fff;
      box-shadow: 0 4px 14px rgba(244,63,94,0.3);
    }
    .adm-btn-red:hover { box-shadow: 0 8px 22px rgba(244,63,94,0.4); }

    .adm-btn-ghost {
      background: #f5f3ff; color: #6366f1;
      border: 1.5px solid #e0e7ff;
    }
    .adm-btn-ghost:hover { background: #ede9fe; }

    /* ── Category cards ── */
    .adm-cat {
      background: #fff;
      border: 2px solid #f0f0f0;
      border-radius: 16px;
      padding: 18px 26px;
      min-width: 150px;
      text-align: center;
      cursor: pointer;
      transition: all 0.25s cubic-bezier(.4,0,.2,1);
      font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .adm-cat:hover {
      border-color: #a5b4fc;
      transform: translateY(-4px);
      box-shadow: 0 12px 32px rgba(99,102,241,0.12);
    }
    .adm-cat.active {
      border-color: #6366f1;
      background: linear-gradient(135deg,#f5f3ff,#ede9fe);
      box-shadow: 0 8px 28px rgba(99,102,241,0.18);
    }
    .adm-cat h3 {
      font-size: 14px; font-weight: 700;
      color: #1e1b4b; margin: 0;
    }
    .adm-cat.active h3 { color: #4338ca; }

    /* ── Stat cards ── */
    .adm-stat {
      background: #fff;
      border: 1.5px solid #f0f0f0;
      border-radius: 20px;
      padding: 26px 20px;
      text-align: center;
      transition: all 0.22s;
      position: relative;
      overflow: hidden;
    }
    .adm-stat::before {
      content: '';
      position: absolute; top: 0; left: 0; right: 0; height: 4px;
      background: linear-gradient(90deg,#6366f1,#8b5cf6,#a78bfa);
    }
    .adm-stat:hover {
      transform: translateY(-4px);
      box-shadow: 0 16px 40px rgba(99,102,241,0.12);
      border-color: #e0e7ff;
    }
    .adm-stat-label {
      font-size: 11px; font-weight: 600;
      color: #9ca3af; text-transform: uppercase;
      letter-spacing: 0.1em; margin-bottom: 10px;
    }
    .adm-stat-value {
      font-family: 'Fraunces', serif;
      font-size: 38px; font-weight: 900;
      background: linear-gradient(135deg,#6366f1,#8b5cf6);
      -webkit-background-clip: text; -webkit-text-fill-color: transparent;
      line-height: 1;
    }

    /* ── Product cards - UPDATED LARGER SIZE ── */
    .adm-product {
      background: #fff;
      border: 1.5px solid #f0f0f0;
      border-radius: 24px;
      overflow: hidden;
      transition: all 0.3s cubic-bezier(.4,0,.2,1);
      animation: adm-fadeUp 0.4s ease both;
      animation-delay: var(--adm-delay, 0s);
    }
    .adm-product:hover {
      transform: translateY(-8px);
      box-shadow: 0 25px 50px rgba(99,102,241,0.15);
      border-color: #c7d2fe;
    }
    /* Larger image wrapper */
    .adm-product-img-wrap {
      position: relative;
      height: 260px;
      background: #f8f7ff;
      overflow: hidden;
    }
    .adm-product-img-wrap img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.5s ease;
    }
    .adm-product:hover .adm-product-img-wrap img { transform: scale(1.08); }
    /* Larger body padding */
    .adm-product-body {
      padding: 20px;
    }
    /* Larger product name */
    .adm-product-name {
      font-size: 18px;
      font-weight: 800;
      color: #1e1b4b;
      margin-bottom: 12px;
      line-height: 1.3;
      min-height: 52px;
    }
    /* Larger action buttons */
    .adm-act-edit {
      flex: 1;
      padding: 10px 0;
      font-family: 'Plus Jakarta Sans', sans-serif;
      font-size: 13px;
      font-weight: 700;
      background: #f5f3ff;
      color: #6366f1;
      border: 1.5px solid #e0e7ff;
      border-radius: 12px;
      cursor: pointer;
      transition: all 0.2s;
    }
    .adm-act-edit:hover {
      background: #ede9fe;
      border-color: #a5b4fc;
      transform: translateY(-1px);
    }
    .adm-act-del {
      flex: 1;
      padding: 10px 0;
      font-family: 'Plus Jakarta Sans', sans-serif;
      font-size: 13px;
      font-weight: 700;
      background: #fff1f2;
      color: #f43f5e;
      border: 1.5px solid #fecdd3;
      border-radius: 12px;
      cursor: pointer;
      transition: all 0.2s;
    }
    .adm-act-del:hover {
      background: #ffe4e6;
      border-color: #fda4af;
      transform: translateY(-1px);
    }

    /* ── Modal ── */
    .adm-overlay {
      position: fixed; inset: 0; z-index: 1000;
      background: rgba(15,10,40,0.42);
      backdrop-filter: blur(7px);
      display: flex; align-items: center; justify-content: center;
      animation: adm-fadeUp 0.2s ease;
    }
    .adm-modal {
      background: #fff;
      border-radius: 24px;
      padding: 40px 36px 32px;
      width: 90%; max-width: 440px;
      position: relative;
      box-shadow: 0 40px 100px rgba(99,102,241,0.18), 0 0 0 1px rgba(99,102,241,0.08);
      animation: adm-pop 0.28s cubic-bezier(.34,1.56,.64,1) both;
    }
    .adm-modal-title {
      font-family: 'Fraunces', serif;
      font-size: 22px; font-weight: 900;
      color: #1e1b4b; margin-bottom: 24px;
    }
    .adm-modal-close {
      position: absolute; top: 16px; right: 16px;
      width: 32px; height: 32px;
      background: #f5f3ff; border: none; border-radius: 8px;
      color: #6366f1; font-size: 14px;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
      transition: all 0.2s;
    }
    .adm-modal-close:hover { background: #ede9fe; }

    /* ── Input ── */
    .adm-input {
      width: 100%; padding: 13px 16px; margin-bottom: 14px;
      background: #fafafa; border: 1.5px solid #e5e7eb;
      border-radius: 12px; font-size: 14px; font-weight: 500;
      font-family: 'Plus Jakarta Sans', sans-serif;
      color: #1e1b4b; outline: none; transition: all 0.2s;
    }
    .adm-input::placeholder { color: #d1d5db; }
    .adm-input:focus { border-color: #6366f1; background: #fff; box-shadow: 0 0 0 4px rgba(99,102,241,0.1); }

    /* ── Misc ── */
    .adm-badge-discount {
      display: inline-flex; align-items: center;
      background: linear-gradient(135deg,#fef3c7,#fde68a);
      color: #92400e;
      font-family: 'Plus Jakarta Sans', sans-serif;
      font-size: 11px; font-weight: 700;
      padding: 3px 10px; border-radius: 20px;
      border: 1px solid #fcd34d; letter-spacing: 0.04em; margin-top: 6px;
    }
    .adm-divider {
      height: 1px; margin: 40px 0;
      background: linear-gradient(90deg,transparent,#e0e7ff 30%,#e0e7ff 70%,transparent);
    }
    .adm-empty {
      text-align: center; padding: 60px 20px;
      background: #fafafa; border-radius: 20px;
      border: 2px dashed #e0e7ff;
    }
    .adm-section-tag {
      display: inline-block;
      background: #f5f3ff; color: #6366f1;
      font-family: 'Plus Jakarta Sans', sans-serif;
      font-size: 11px; font-weight: 700;
      padding: 3px 10px; border-radius: 20px;
      letter-spacing: 0.06em; text-transform: uppercase;
      border: 1px solid #e0e7ff; margin-bottom: 6px;
    }
    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: #f9f9f9; }
    ::-webkit-scrollbar-thumb { background: #e0e7ff; border-radius: 10px; }

    /* Product quantity and price styling */
    .product-quantity {
      font-size: 13px;
      font-weight: 600;
      color: #6b7280;
    }
    .product-price {
      font-family: 'Fraunces', serif;
      font-size: 22px;
      font-weight: 900;
      color: #6366f1;
    }
  `;
  document.head.appendChild(el);
};
injectStyles();

// Helper function to compress image
const compressImage = (file, maxWidth = 800, quality = 0.7) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (e) => {
      const img = new Image();
      img.src = e.target.result;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        
        if (width > maxWidth) {
          height = (height * maxWidth) / width;
          width = maxWidth;
        }
        
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);
        
        const compressedBase64 = canvas.toDataURL('image/jpeg', quality);
        resolve(compressedBase64);
      };
      img.onerror = reject;
    };
    reader.onerror = reject;
  });
};

// ─── Component ────────────────────────────────────────────────────────────────
function AdminDashboard() {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const [categories, setCategories]               = useState([]);
  const [selectedCategory, setSelectedCategory]   = useState(null);
  const [loading, setLoading]                     = useState(true);
  const [showProductForm, setShowProductForm]     = useState(false);
  const [editingProduct, setEditingProduct]       = useState(null);
  const [showAddCategoryForm, setShowAddCategoryForm] = useState(false);
  const [showEditCategoryForm, setShowEditCategoryForm] = useState(false);
  const [newCategoryName, setNewCategoryName]     = useState('');
  const [editCategoryName, setEditCategoryName]   = useState('');
  const [productForm, setProductForm]             = useState({ name:'', imageUrl:'', quantity:'', price:'', discount:'' });
  const [selectedProductId, setSelectedProductId] = useState(null);
  const [imagePreview, setImagePreview]           = useState(null);

  const loadCategories = useCallback(async () => {
    try {
      setLoading(true);
      const res = await api.get('/categories');
      const list = res.data.data || [];
      setCategories(list);
      if (list.length > 0 && !selectedCategory) loadCategoryWithProducts(list[0].id);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  }, []);

  const loadCategoryWithProducts = async (id) => {
    try {
      const res = await api.get(`/categories/${id}`);
      const data = res.data.data;
      setSelectedCategory(data);
      setCategories(prev => prev.map(c => c.id === id ? { ...c, products: data.products } : c));
    } catch (err) { console.error(err); }
  };

  useEffect(() => { loadCategories(); }, [loadCategories]);

  const handleSelectCategory = (cat) => { setSelectedProductId(null); loadCategoryWithProducts(cat.id); };
  const getTotalQuantity = (p=[]) => p.reduce((s, x) => s + Number(x.quantity || 0), 0);

  const handleAddProduct = () => {
    setEditingProduct(null);
    setProductForm({ name:'', imageUrl:'', quantity:'', price:'', discount:'' });
    setImagePreview(null);
    setShowProductForm(true);
  };

  const handleEditProduct = (p) => {
    setEditingProduct(p);
    setProductForm({ 
      name: p.name, 
      imageUrl: p.image || p.imageUrl || '', 
      quantity: p.quantity, 
      price: p.price, 
      discount: p.discount || '' 
    });
    setImagePreview(p.image || p.imageUrl || null);
    setShowProductForm(true);
  };

  const handleImageSelect = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    // Validate file type
    if (!file.type.startsWith('image/')) {
      alert('Please select an image file');
      return;
    }
    
    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      alert('Image size should be less than 2MB');
      return;
    }
    
    try {
      // Compress image and convert to Base64
      const base64String = await compressImage(file, 800, 0.7);
      setImagePreview(base64String);
      setProductForm({ ...productForm, imageUrl: base64String });
    } catch (error) {
      console.error('Error processing image:', error);
      alert('Failed to process image');
    }
  };

  const handleSaveProduct = async (e) => {
    e.preventDefault();
    if (!selectedCategory) return;
    
    try {
      const payload = {
        name: productForm.name,
        imageUrl: productForm.imageUrl,
        price: Number(productForm.price),
        quantity: Number(productForm.quantity),
        discount: productForm.discount || '',
        categoryId: selectedCategory.id,
      };

      if (editingProduct) {
        await api.put(`/products/${editingProduct.id}`, payload);
      } else {
        await api.post('/products', payload);
      }

      await loadCategoryWithProducts(selectedCategory.id);
      setShowProductForm(false);
      setProductForm({ name: '', imageUrl: '', quantity: '', price: '', discount: '' });
      setEditingProduct(null);
      setImagePreview(null);
    } catch (err) {
      console.error('Save error:', err);
      alert(err.response?.data?.message || 'Failed to save product.');
    }
  };

  const handleDeleteProduct = async (id, name) => {
    if (!window.confirm(`Delete "${name}"?`)) return;
    try { 
      await api.delete(`/products/${id}`); 
      await loadCategoryWithProducts(selectedCategory.id); 
      setSelectedProductId(null); 
    } catch (err) { 
      alert(err.response?.data?.message || 'Delete failed.'); 
    }
  };

  const handleAddCategory = async () => {
    if (!newCategoryName.trim()) { alert('Enter category name'); return; }
    try { 
      await api.post('/categories', { name: newCategoryName }); 
      await loadCategories(); 
      setShowAddCategoryForm(false); 
      setNewCategoryName(''); 
    } catch (err) { 
      alert(err.response?.data?.message || 'Failed.'); 
    }
  };

  const handleUpdateCategory = async () => {
    if (!selectedCategory || !editCategoryName.trim()) return;
    try { 
      await api.put(`/categories/${selectedCategory.id}`, { name: editCategoryName }); 
      await loadCategories(); 
      setShowEditCategoryForm(false); 
      setEditCategoryName(''); 
      loadCategoryWithProducts(selectedCategory.id); 
    } catch (err) { 
      alert(err.response?.data?.message || 'Failed.'); 
    }
  };

  const handleDeleteCategory = async () => {
    if (!selectedCategory || !window.confirm(`Delete "${selectedCategory.name}" and all its products?`)) return;
    try { 
      await api.delete(`/categories/${selectedCategory.id}`); 
      setSelectedCategory(null); 
      await loadCategories(); 
    } catch (err) { 
      alert(err.response?.data?.message || 'Delete failed.'); 
    }
  };

  const openEditCategoryForm = () => { 
    setEditCategoryName(selectedCategory?.name || ''); 
    setShowEditCategoryForm(true); 
  };

  const handleLogout = async () => { 
    await logout(); 
    navigate('/login'); 
  };

  if (loading) return (
    <div style={{ minHeight:'100vh', background:'#f8f7ff', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:20 }}>
      <div style={{ width:48, height:48, border:'3px solid #e0e7ff', borderTop:'3px solid #6366f1', borderRadius:'50%', animation:'adm-spin 0.8s linear infinite' }} />
      <p style={{ fontFamily:'Fraunces,serif', color:'#6366f1', fontSize:20, fontWeight:900 }}>Loading…</p>
    </div>
  );

  return (
    <div style={{ minHeight:'100vh', background:'#f8f7ff', fontFamily:"'Plus Jakarta Sans',sans-serif" }}>

      {/* Topbar */}
      <div className="adm-topbar">
        <div className="adm-brand">
          <div className="adm-brand-icon">🛍️</div>
          <span className="adm-brand-name">ShopAdmin</span>
        </div>
        <div style={{ display:'flex', gap:10 }}>
          <button className="adm-btn adm-btn-ghost" onClick={() => navigate('/AdminProfile')}>👤 Profile</button>
          <button className="adm-btn adm-btn-red" onClick={handleLogout}>🚪 Logout</button>
        </div>
      </div>

      {/* Page content */}
      <div style={{ maxWidth:1280, margin:'0 auto', padding:'44px 32px 80px' }}>

        {/* Heading */}
        <div style={{ marginBottom:44 }}>
          <h1 style={{ fontFamily:"'Fraunces',serif", fontSize:42, fontWeight:900, color:'#1e1b4b', letterSpacing:'-0.03em', lineHeight:1.1, marginBottom:8 }}>
            Dashboard
          </h1>
          <p style={{ color:'#9ca3af', fontSize:14, fontWeight:500 }}>Manage your store categories &amp; products</p>
        </div>

        {/* Categories */}
        <section>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:20, flexWrap:'wrap', gap:14 }}>
            <div>
              <span className="adm-section-tag">Catalogue</span>
              <h2 style={{ fontFamily:"'Fraunces',serif", fontSize:22, fontWeight:900, color:'#1e1b4b', marginTop:4 }}>
                Categories
                <span style={{ marginLeft:10, fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:13, fontWeight:600, color:'#9ca3af', verticalAlign:'middle' }}>
                  {categories.length}
                </span>
              </h2>
            </div>
            <button className="adm-btn adm-btn-violet" onClick={() => setShowAddCategoryForm(true)}>+ Add Category</button>
          </div>
          <div style={{ display:'flex', flexWrap:'wrap', gap:14 }}>
            {categories.map(cat => (
              <div key={cat.id} className={`adm-cat${selectedCategory?.id === cat.id ? ' active' : ''}`} onClick={() => handleSelectCategory(cat)}>
                <h3>{cat.name}</h3>
                {cat.discount && <div className="adm-badge-discount">{cat.discount}</div>}
              </div>
            ))}
            {categories.length === 0 && <p style={{ color:'#d1d5db', fontSize:14, padding:'16px 0' }}>No categories yet.</p>}
          </div>
        </section>

        {/* Products */}
        {selectedCategory && (
          <>
            <div className="adm-divider" />
            <section style={{ animation:'adm-fadeUp 0.4s ease' }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:24, flexWrap:'wrap', gap:14 }}>
                <div>
                  <span className="adm-section-tag">Products</span>
                  <h2 style={{ fontFamily:"'Fraunces',serif", fontSize:22, fontWeight:900, color:'#1e1b4b', marginTop:4 }}>{selectedCategory.name}</h2>
                </div>
                <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}>
                  <button className="adm-btn adm-btn-amber" onClick={openEditCategoryForm}>✏️ Edit</button>
                  <button className="adm-btn adm-btn-red" onClick={handleDeleteCategory}>🗑️ Delete</button>
                  <button className="adm-btn adm-btn-violet" onClick={handleAddProduct}>+ Add Product</button>
                </div>
              </div>

              {/* Stats */}
              <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(170px,1fr))', gap:16, marginBottom:28 }}>
                {[
                  { label:'Total Stock',       value: getTotalQuantity(selectedCategory.products) },
                  { label:'Products Sold',     value: selectedCategory.sold || 0 },
                  { label:'Remaining Stock',   value: getTotalQuantity(selectedCategory.products) - (selectedCategory.sold||0) },
                  { label:'Category Discount', value: selectedCategory.discount || '0%' },
                ].map(({ label, value }) => (
                  <div key={label} className="adm-stat">
                    <div className="adm-stat-label">{label}</div>
                    <div className="adm-stat-value">{value}</div>
                  </div>
                ))}
              </div>

              {/* Grid - Updated with larger card layout */}
              {(!selectedCategory.products || selectedCategory.products.length === 0) ? (
                <div className="adm-empty">
                  <div style={{ fontSize:40, marginBottom:14 }}>📦</div>
                  <p style={{ color:'#9ca3af', fontSize:14, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>
                    No products yet. Click <strong style={{ color:'#6366f1' }}>Add Product</strong> to get started.
                  </p>
                </div>
              ) : (
                <div style={{ 
                  display: 'grid', 
                  gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', 
                  gap: '28px' 
                }}>
                  {selectedCategory.products.map((product, i) => (
                    <div
                      key={product.id}
                      className="adm-product"
                      style={{ 
                        '--adm-delay': `${i*0.05}s`, 
                        outline: selectedProductId === product.id ? '3px solid #6366f1' : 'none', 
                        outlineOffset: 2 
                      }}
                      onClick={() => setSelectedProductId(product.id)}
                    >
                      <div className="adm-product-img-wrap">
                        <img 
                          src={product.image || product.imageUrl || 'https://via.placeholder.com/400x260?text=No+Image'} 
                          alt={product.name} 
                          onError={(e)=>{ e.target.src='https://via.placeholder.com/400x260?text=No+Image'; }} 
                        />
                        {product.discount && (
                          <div style={{ 
                            position:'absolute', 
                            top:12, 
                            right:12, 
                            background:'linear-gradient(135deg,#f59e0b,#d97706)', 
                            color:'#fff', 
                            fontSize:13, 
                            fontWeight:800, 
                            padding:'6px 14px', 
                            borderRadius:25, 
                            fontFamily:"'Plus Jakarta Sans',sans-serif", 
                            boxShadow:'0 3px 10px rgba(245,158,11,0.4)' 
                          }}>
                            {product.discount} OFF
                          </div>
                        )}
                      </div>
                      <div className="adm-product-body">
                        <div className="adm-product-name">{product.name}</div>
                        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:15 }}>
                          <span className="product-quantity">📦 Qty: {product.quantity}</span>
                          <span className="product-price">
                            ₹{Number(product.price).toLocaleString('en-IN')}
                          </span>
                        </div>
                        <div style={{ display:'flex', gap:12 }}>
                          <button className="adm-act-edit" onClick={(e)=>{ e.stopPropagation(); handleEditProduct(product); }}>✏️ Edit</button>
                          <button className="adm-act-del"  onClick={(e)=>{ e.stopPropagation(); handleDeleteProduct(product.id, product.name); }}>🗑️ Delete</button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </>
        )}
      </div>

      {/* ── Modals ── */}
      {showAddCategoryForm && (
        <div className="adm-overlay" onClick={() => setShowAddCategoryForm(false)}>
          <div className="adm-modal" onClick={e => e.stopPropagation()}>
            <button className="adm-modal-close" onClick={() => setShowAddCategoryForm(false)}>✕</button>
            <div className="adm-modal-title">New Category</div>
            <input className="adm-input" placeholder="Category name…" value={newCategoryName}
              onChange={e => setNewCategoryName(e.target.value)} autoFocus
              onKeyDown={e => e.key==='Enter' && handleAddCategory()} />
            <button className="adm-btn adm-btn-violet" style={{ width:'100%', padding:'13px', fontSize:15, borderRadius:14 }} onClick={handleAddCategory}>
              Add Category
            </button>
          </div>
        </div>
      )}

      {showEditCategoryForm && (
        <div className="adm-overlay" onClick={() => setShowEditCategoryForm(false)}>
          <div className="adm-modal" onClick={e => e.stopPropagation()}>
            <button className="adm-modal-close" onClick={() => setShowEditCategoryForm(false)}>✕</button>
            <div className="adm-modal-title">Edit Category</div>
            <input className="adm-input" placeholder="Category name…" value={editCategoryName}
              onChange={e => setEditCategoryName(e.target.value)} autoFocus
              onKeyDown={e => e.key==='Enter' && handleUpdateCategory()} />
            <button className="adm-btn adm-btn-amber" style={{ width:'100%', padding:'13px', fontSize:15, borderRadius:14 }} onClick={handleUpdateCategory}>
              Update Category
            </button>
          </div>
        </div>
      )}

      {showProductForm && (
        <div className="adm-overlay" onClick={() => setShowProductForm(false)}>
          <div className="adm-modal" onClick={e => e.stopPropagation()} style={{ maxWidth:460, maxHeight:'90vh', overflowY:'auto' }}>
            <button className="adm-modal-close" onClick={() => setShowProductForm(false)}>✕</button>
            <div className="adm-modal-title">{editingProduct ? 'Edit Product' : 'New Product'}</div>
            <form onSubmit={handleSaveProduct}>

              {/* Image Upload - Base64 Version */}
              <div
                onClick={() => document.getElementById('adm-file-input').click()}
                style={{
                  marginBottom:16, borderRadius:14, overflow:'hidden',
                  border: imagePreview ? 'none' : '2px dashed #c7d2fe',
                  background: imagePreview ? 'transparent' : '#f5f3ff',
                  cursor:'pointer', transition:'all 0.2s',
                  minHeight: imagePreview ? 'auto' : 120,
                  display:'flex', flexDirection:'column',
                  alignItems:'center', justifyContent:'center', gap:8,
                }}
              >
                {imagePreview ? (
                  <div style={{ position:'relative' }}>
                    <img src={imagePreview} alt="preview"
                      style={{ width:'100%', maxHeight:200, objectFit:'cover', borderRadius:12, display:'block' }} />
                    <div style={{
                      position:'absolute', inset:0, background:'rgba(99,102,241,0.5)',
                      borderRadius:12, display:'flex', alignItems:'center', justifyContent:'center',
                      opacity:0, transition:'opacity 0.2s',
                    }}
                      onMouseEnter={e => e.currentTarget.style.opacity=1}
                      onMouseLeave={e => e.currentTarget.style.opacity=0}
                    >
                      <span style={{ color:'#fff', fontFamily:"'Plus Jakarta Sans',sans-serif", fontWeight:700, fontSize:14 }}>
                        🔄 Change Image
                      </span>
                    </div>
                  </div>
                ) : (
                  <>
                    <span style={{ fontSize:32 }}>📸</span>
                    <span style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:13, fontWeight:600, color:'#818cf8' }}>
                      Click to upload image
                    </span>
                    <span style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:11, color:'#a5b4fc' }}>
                      JPG, PNG, WEBP (Max 2MB)
                    </span>
                  </>
                )}
              </div>
              
              <input
                id="adm-file-input"
                type="file"
                accept="image/*"
                style={{ display:'none' }}
                onChange={handleImageSelect}
              />

              <input className="adm-input" placeholder="Product Name" type="text" required
                value={productForm.name} onChange={e => setProductForm({ ...productForm, name:e.target.value })} />
              <input className="adm-input" placeholder="Quantity" type="number" min={0} required
                value={productForm.quantity} onChange={e => setProductForm({ ...productForm, quantity:e.target.value })} />
              <input className="adm-input" placeholder="Price (₹)" type="number" min={0} step={1} required
                value={productForm.price} onChange={e => setProductForm({ ...productForm, price:e.target.value })} />
              <input className="adm-input" placeholder="Discount (e.g. 15%)" type="text"
                value={productForm.discount} onChange={e => setProductForm({ ...productForm, discount:e.target.value })} />

              <button type="submit" className="adm-btn adm-btn-violet" style={{ width:'100%', padding:'13px', fontSize:15, borderRadius:14 }}>
                {editingProduct ? 'Update Product' : 'Add Product'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default AdminDashboard;