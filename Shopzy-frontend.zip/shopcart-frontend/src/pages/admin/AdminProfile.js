import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { adminTheme } from "../../theme";

function AdminProfile() {
  const navigate = useNavigate();
  const [lastLogin, setLastLogin] = useState("");

  useEffect(() => {
    // Previous session's login time show cheyyadam
    const stored = localStorage.getItem("adminLastLogin");
    if (stored) {
      setLastLogin(stored);
    } else {
      setLastLogin("First login");
    }

    // Current login time save cheyyadam (next visit lo show avutundi)
    const now = new Date();
    const formatted = now.toLocaleString("en-IN", {
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    });
    localStorage.setItem("adminLastLogin", formatted);
  }, []);

  const admin = {
    name: "Admin User",
    email: "admin@example.com",
    role: "Administrator",
    joined: "January 2024",
    lastLogin: lastLogin || "Loading...",
  };

  // ... rest of your component (infoItems, JSX) same గా ఉంటాయి

  const infoItems = [
    {
      icon: (
        <svg width="16" height="16" fill="none" stroke={adminTheme.primary} strokeWidth="2" viewBox="0 0 24 24">
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" />
        </svg>
      ),
      bgColor: "#EBF4FF",
      label: "Name",
      value: admin.name,
    },
    {
      icon: (
        <svg width="16" height="16" fill="none" stroke={adminTheme.primary} strokeWidth="2" viewBox="0 0 24 24">
          <rect x="2" y="4" width="20" height="16" rx="2" /><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
        </svg>
      ),
      bgColor: "#EBF4FF",
      label: "Email",
      value: admin.email,
    },
    {
      icon: (
        <svg width="16" height="16" fill="none" stroke={adminTheme.primary} strokeWidth="2" viewBox="0 0 24 24">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
        </svg>
      ),
      bgColor: "#EBF4FF",
      label: "Role",
      value: admin.role,
    },
    {
      icon: (
        <svg width="16" height="16" fill="none" stroke="#3B6D11" strokeWidth="2" viewBox="0 0 24 24">
          <rect x="3" y="4" width="18" height="18" rx="2" /><path d="M16 2v4M8 2v4M3 10h18" />
        </svg>
      ),
      bgColor: "#EAF3DE",
      label: "Member Since",
      value: admin.joined,
    },
    {
      icon: (
        <svg width="16" height="16" fill="none" stroke="#854F0B" strokeWidth="2" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="10" /><path d="M12 6v6l4 2" />
        </svg>
      ),
      bgColor: "#FAEEDA",
      label: "Last Login",
      value: admin.lastLogin,
    },
  ];

  return (
    <div style={styles.page}>
      <div style={styles.card}>

        {/* Header Section */}
        <div style={styles.header}>
          <button style={styles.backBtn} onClick={() => navigate("/admin-home")}>
            ← Back
          </button>
          <div style={styles.avatarCircle}>👤</div>
          <h2 style={styles.adminName}>{admin.name}</h2>
          <span style={styles.roleBadge}>{admin.role}</span>
        </div>

        {/* Info Rows */}
        <div style={styles.body}>
          {infoItems.map((item, i) => (
            <div
              key={i}
              style={{
                ...styles.infoRow,
                borderBottom: i < infoItems.length - 1 ? "0.5px solid #e5e7eb" : "none",
              }}
            >
              <div style={{ ...styles.iconBox, backgroundColor: item.bgColor }}>
                {item.icon}
              </div>
              <div>
                <p style={styles.infoLabel}>{item.label}</p>
                <p style={styles.infoValue}>{item.value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Footer Button */}
        

      </div>
    </div>
  );
}

export default AdminProfile;

const styles = {
  page: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "2rem",
    background: "#f3f4f6",
  },
  card: {
    width: "100%",
    maxWidth: "440px",
    background: "#ffffff",
    borderRadius: "24px",
    boxShadow: "0 4px 24px rgba(0,0,0,0.08)",
    overflow: "hidden",
  },
  header: {
    background: "linear-gradient(135deg, #185FA5 0%, #042C53 100%)",
    padding: "2rem",
    textAlign: "center",
    position: "relative",
  },
  backBtn: {
    position: "absolute",
    top: "16px",
    left: "16px",
    background: "rgba(255,255,255,0.15)",
    border: "0.5px solid rgba(255,255,255,0.3)",
    color: "white",
    padding: "6px 14px",
    borderRadius: "20px",
    fontSize: "13px",
    cursor: "pointer",
  },
  avatarCircle: {
    width: "80px",
    height: "80px",
    borderRadius: "50%",
    background: "rgba(255,255,255,0.2)",
    border: "3px solid rgba(255,255,255,0.4)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    margin: "0 auto 1rem",
    fontSize: "36px",
  },
  adminName: {
    color: "white",
    margin: "0 0 6px",
    fontSize: "20px",
    fontWeight: "500",
  },
  roleBadge: {
    display: "inline-block",
    background: "rgba(255,255,255,0.2)",
    color: "rgba(255,255,255,0.9)",
    fontSize: "12px",
    padding: "3px 14px",
    borderRadius: "20px",
    border: "0.5px solid rgba(255,255,255,0.3)",
  },
  body: {
    padding: "1rem 1.5rem",
  },
  infoRow: {
    display: "flex",
    alignItems: "center",
    gap: "14px",
    padding: "14px 0",
  },
  iconBox: {
    width: "36px",
    height: "36px",
    borderRadius: "10px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  infoLabel: {
    margin: 0,
    fontSize: "12px",
    color: "#6b7280",
  },
  infoValue: {
    margin: 0,
    fontSize: "15px",
    fontWeight: "500",
    color: "#111827",
  },
  footer: {
    padding: "0 1.5rem 1.5rem",
  },
  editBtn: {
    width: "100%",
    padding: "12px",
    background: "#185FA5",
    color: "white",
    border: "none",
    borderRadius: "12px",
    fontSize: "15px",
    fontWeight: "500",
    cursor: "pointer",
  },
};