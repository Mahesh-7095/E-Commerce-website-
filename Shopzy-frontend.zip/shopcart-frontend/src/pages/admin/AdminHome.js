import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../services/api';
import { useAuth } from '../../context/AuthContext';

// ─── Inject Global Styles ────────────────────────────────────────────────────
const injectStyles = () => {
  if (document.getElementById('adm-home-styles')) return;
  const el = document.createElement('style');
  el.id = 'adm-home-styles';
  el.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fraunces:wght@700;900&display=swap');
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    @keyframes ah-spin   { to { transform: rotate(360deg); } }
    @keyframes ah-fadeUp { from { opacity:0; transform:translateY(16px); } to { opacity:1; transform:translateY(0); } }
    @keyframes ah-pop    { 0%{transform:scale(0.93);opacity:0} 100%{transform:scale(1);opacity:1} }

    .ah-topbar {
      position: sticky; top: 0; z-index: 200;
      display: flex; justify-content: space-between; align-items: center;
      padding: 0 40px; height: 68px;
      background: rgba(255,255,255,0.9); backdrop-filter: blur(18px);
      border-bottom: 1px solid #ede9fe;
      box-shadow: 0 2px 24px rgba(99,102,241,0.07);
    }
    .ah-brand { display: flex; align-items: center; gap: 12px; }
    .ah-brand-icon {
      width: 38px; height: 38px; border-radius: 11px;
      background: linear-gradient(135deg,#6366f1,#8b5cf6);
      display: flex; align-items: center; justify-content: center;
      font-size: 18px; box-shadow: 0 4px 14px rgba(99,102,241,0.38);
    }
    .ah-brand-name {
      font-family: 'Fraunces', serif; font-size: 21px; font-weight: 900;
      background: linear-gradient(135deg,#6366f1,#8b5cf6);
      -webkit-background-clip: text; -webkit-text-fill-color: transparent;
    }
    .ah-tabs { display:flex; gap:6px; background:#f5f3ff; border-radius:14px; padding:5px; }
    .ah-tab {
      font-family:'Plus Jakarta Sans',sans-serif; font-size:13px; font-weight:700;
      border:none; border-radius:10px; cursor:pointer; padding:9px 20px;
      transition:all 0.2s; color:#6b7280; background:transparent;
      display:inline-flex; align-items:center; gap:7px;
    }
    .ah-tab:hover  { color:#4f46e5; background:rgba(99,102,241,0.08); }
    .ah-tab.active { background:#fff; color:#4f46e5; box-shadow:0 2px 12px rgba(99,102,241,0.18); }

    .ah-btn {
      font-family:'Plus Jakarta Sans',sans-serif; font-weight:600; font-size:13px;
      border:none; border-radius:12px; cursor:pointer; padding:10px 20px;
      transition:all 0.22s; display:inline-flex; align-items:center; gap:6px;
    }
    .ah-btn:hover  { transform:translateY(-2px); }
    .ah-btn:active { transform:translateY(0) scale(0.98); }
    .ah-btn-violet { background:linear-gradient(135deg,#6366f1,#8b5cf6); color:#fff; box-shadow:0 4px 14px rgba(99,102,241,0.35); }
    .ah-btn-violet:hover { box-shadow:0 8px 24px rgba(99,102,241,0.45); }
    .ah-btn-amber  { background:linear-gradient(135deg,#f59e0b,#d97706); color:#fff; box-shadow:0 4px 14px rgba(245,158,11,0.3); }
    .ah-btn-red    { background:linear-gradient(135deg,#f43f5e,#e11d48); color:#fff; box-shadow:0 4px 14px rgba(244,63,94,0.3); }
    .ah-btn-ghost  { background:#f5f3ff; color:#6366f1; border:1.5px solid #e0e7ff; }
    .ah-btn-ghost:hover { background:#ede9fe; }

    .ah-stat {
      background:#fff; border:1.5px solid #f0f0f0; border-radius:20px;
      padding:26px 20px; text-align:center; transition:all 0.22s;
      position:relative; overflow:hidden;
    }
    .ah-stat::before { content:''; position:absolute; top:0; left:0; right:0; height:4px; background:linear-gradient(90deg,#6366f1,#8b5cf6,#a78bfa); }
    .ah-stat:hover { transform:translateY(-4px); box-shadow:0 16px 40px rgba(99,102,241,0.12); border-color:#e0e7ff; }
    .ah-stat-label { font-size:11px; font-weight:600; color:#9ca3af; text-transform:uppercase; letter-spacing:0.1em; margin-bottom:10px; }
    .ah-stat-value { font-family:'Fraunces',serif; font-size:36px; font-weight:900; background:linear-gradient(135deg,#6366f1,#8b5cf6); -webkit-background-clip:text; -webkit-text-fill-color:transparent; line-height:1; }

    .ah-table { width:100%; border-collapse:collapse; font-family:'Plus Jakarta Sans',sans-serif; }
    .ah-table thead { background:#f8f7ff; }
    .ah-table th { text-align:left; padding:14px 18px; font-size:11px; font-weight:700; color:#9ca3af; text-transform:uppercase; letter-spacing:0.08em; border-bottom:2px solid #ede9fe; }
    .ah-table td { padding:14px 18px; font-size:14px; color:#374151; border-bottom:1px solid #f3f4f6; vertical-align:middle; }
    .ah-table tr:hover td { background:#fafafe; }
    .ah-table tr:last-child td { border-bottom:none; }

    .ah-badge { display:inline-flex; align-items:center; gap:5px; padding:5px 13px; border-radius:20px; font-size:11px; font-weight:700; letter-spacing:0.04em; }
    .ah-badge-processing { background:#fff8e1; color:#e65100; border:1.5px solid #ffcc02; }
    .ah-badge-shipped    { background:#e3f2fd; color:#1565c0; border:1.5px solid #90caf9; }
    .ah-badge-delivered  { background:#e8f5e9; color:#2e7d32; border:1.5px solid #81c784; }
    .ah-badge-cancelled  { background:#ffebee; color:#c62828; border:1.5px solid #ef9a9a; }

    .ah-status-select {
      font-family:'Plus Jakarta Sans',sans-serif; font-size:12px; font-weight:600;
      border:1.5px solid #e0e7ff; border-radius:10px; padding:7px 12px;
      background:#f8f7ff; color:#4338ca; cursor:pointer; outline:none; transition:all 0.2s;
    }
    .ah-status-select:hover { border-color:#a5b4fc; background:#ede9fe; }
    .ah-status-select:focus { border-color:#6366f1; box-shadow:0 0 0 3px rgba(99,102,241,0.15); }
    .ah-status-select:disabled { opacity:0.5; cursor:not-allowed; }

    .ah-overlay { position:fixed; inset:0; z-index:1000; background:rgba(15,10,40,0.42); backdrop-filter:blur(7px); display:flex; align-items:center; justify-content:center; animation:ah-fadeUp 0.2s ease; }
    .ah-modal { background:#fff; border-radius:24px; padding:40px 36px 32px; width:90%; max-width:440px; position:relative; box-shadow:0 40px 100px rgba(99,102,241,0.18); animation:ah-pop 0.28s cubic-bezier(.34,1.56,.64,1) both; }
    .ah-modal-title { font-family:'Fraunces',serif; font-size:22px; font-weight:900; color:#1e1b4b; margin-bottom:20px; }
    .ah-modal-close { position:absolute; top:16px; right:16px; width:32px; height:32px; background:#f5f3ff; border:none; border-radius:8px; color:#6366f1; font-size:14px; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:all 0.2s; }
    .ah-modal-close:hover { background:#ede9fe; }
    .ah-input { width:100%; padding:13px 16px; margin-bottom:12px; background:#fafafa; border:1.5px solid #e5e7eb; border-radius:12px; font-size:14px; font-weight:500; font-family:'Plus Jakarta Sans',sans-serif; color:#1e1b4b; outline:none; transition:all 0.2s; }
    .ah-input:focus { border-color:#6366f1; background:#fff; box-shadow:0 0 0 4px rgba(99,102,241,0.1); }

    .ah-divider { height:1px; margin:36px 0; background:linear-gradient(90deg,transparent,#e0e7ff 30%,#e0e7ff 70%,transparent); }
    .ah-empty { text-align:center; padding:56px 20px; background:#fafafa; border-radius:20px; border:2px dashed #e0e7ff; }
    .ah-section-tag { display:inline-block; background:#f5f3ff; color:#6366f1; font-family:'Plus Jakarta Sans',sans-serif; font-size:11px; font-weight:700; padding:3px 10px; border-radius:20px; letter-spacing:0.06em; text-transform:uppercase; border:1px solid #e0e7ff; margin-bottom:6px; }
    .ah-card { background:#fff; border:1.5px solid #f0f0f0; border-radius:20px; overflow:hidden; }

    .ah-order-item { display:flex; align-items:center; gap:12px; padding:10px 0; border-bottom:1px solid #f3f4f6; }
    .ah-order-item:last-child { border-bottom:none; }
    .ah-order-item img { width:48px; height:48px; border-radius:10px; object-fit:cover; background:#f8f7ff; flex-shrink:0; }

    ::-webkit-scrollbar { width:6px; }
    ::-webkit-scrollbar-track { background:#f9f9f9; }
    ::-webkit-scrollbar-thumb { background:#e0e7ff; border-radius:10px; }
  `;
  document.head.appendChild(el);
};
injectStyles();

// ─── Status Badge ─────────────────────────────────────────────────────────────
const StatusBadge = ({ status }) => {
  const cfg = {
    PROCESSING: { cls: 'ah-badge-processing', icon: '⏳', label: 'Processing' },
    SHIPPED:    { cls: 'ah-badge-shipped',    icon: '🚚', label: 'Shipped'    },
    DELIVERED:  { cls: 'ah-badge-delivered',  icon: '✅', label: 'Completed'  },
    CANCELLED:  { cls: 'ah-badge-cancelled',  icon: '✕',  label: 'Cancelled'  },
  };
  const c = cfg[status] || { cls: '', icon: '•', label: status };
  return <span className={`ah-badge ${c.cls}`}>{c.icon} {c.label}</span>;
};

// ─── Spinner ──────────────────────────────────────────────────────────────────
const Spinner = () => (
  <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', padding:'80px 20px', gap:16 }}>
    <div style={{ width:44, height:44, border:'3px solid #e0e7ff', borderTop:'3px solid #6366f1', borderRadius:'50%', animation:'ah-spin 0.8s linear infinite' }} />
    <p style={{ fontFamily:'Fraunces,serif', color:'#6366f1', fontSize:18, fontWeight:900 }}>Loading…</p>
  </div>
);

// ═══════════════════════════════════════════════════════════════════════════════
//  TAB 1 — PRODUCTS
// ═══════════════════════════════════════════════════════════════════════════════
function ProductsTab() {
  const [categories, setCategories]           = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [loading, setLoading]                 = useState(true);
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProduct, setEditingProduct]   = useState(null);
  const [showAddCat, setShowAddCat]           = useState(false);
  const [showEditCat, setShowEditCat]         = useState(false);
  const [newCatName, setNewCatName]           = useState('');
  const [editCatName, setEditCatName]         = useState('');
  const [productForm, setProductForm]         = useState({ name:'', imageUrl:'', quantity:'', price:'', discount:'' });
  const [imagePreview, setImagePreview]       = useState(null);

  const loadCategories = useCallback(async () => {
    try {
      setLoading(true);
      const res = await api.get('/categories');
      const list = res.data.data || [];
      setCategories(list);
      if (list.length > 0) loadCat(list[0].id);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  }, []);

  const loadCat = async (id) => {
    try {
      const res = await api.get(`/categories/${id}`);
      const data = res.data.data;
      setSelectedCategory(data);
      setCategories(prev => prev.map(c => c.id === id ? { ...c, products: data.products } : c));
    } catch (err) { console.error(err); }
  };

  useEffect(() => { loadCategories(); }, [loadCategories]);

  const compress = (file) => new Promise((res, rej) => {
    const r = new FileReader();
    r.readAsDataURL(file);
    r.onload = (e) => {
      const img = new Image(); img.src = e.target.result;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let w = img.width, h = img.height;
        if (w > 800) { h = (h * 800) / w; w = 800; }
        canvas.width = w; canvas.height = h;
        canvas.getContext('2d').drawImage(img, 0, 0, w, h);
        res(canvas.toDataURL('image/jpeg', 0.7));
      };
      img.onerror = rej;
    };
    r.onerror = rej;
  });

  const handleImageSelect = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { alert('Please select an image file'); return; }
    if (file.size > 2 * 1024 * 1024) { alert('Image size should be less than 2MB'); return; }
    try {
      const b64 = await compress(file);
      setImagePreview(b64);
      setProductForm(f => ({ ...f, imageUrl: b64 }));
    } catch { alert('Failed to process image'); }
  };

  const handleSaveProduct = async (e) => {
    e.preventDefault();
    if (!selectedCategory) return;
    const payload = { name: productForm.name, imageUrl: productForm.imageUrl, price: Number(productForm.price), quantity: Number(productForm.quantity), discount: productForm.discount || '', categoryId: selectedCategory.id };
    try {
      editingProduct ? await api.put(`/products/${editingProduct.id}`, payload) : await api.post('/products', payload);
      await loadCat(selectedCategory.id);
      setShowProductForm(false);
      setProductForm({ name:'', imageUrl:'', quantity:'', price:'', discount:'' });
      setEditingProduct(null); setImagePreview(null);
    } catch (err) { alert(err.response?.data?.message || 'Failed to save.'); }
  };

  const handleDeleteProduct = async (id, name) => {
    if (!window.confirm(`Delete "${name}"?`)) return;
    try { await api.delete(`/products/${id}`); await loadCat(selectedCategory.id); }
    catch (err) { alert(err.response?.data?.message || 'Delete failed.'); }
  };

  const handleAddCat = async () => {
    if (!newCatName.trim()) { alert('Enter category name'); return; }
    try { await api.post('/categories', { name: newCatName }); await loadCategories(); setShowAddCat(false); setNewCatName(''); }
    catch (err) { alert(err.response?.data?.message || 'Failed.'); }
  };

  const handleUpdateCat = async () => {
    if (!selectedCategory || !editCatName.trim()) return;
    try { await api.put(`/categories/${selectedCategory.id}`, { name: editCatName }); await loadCategories(); setShowEditCat(false); setEditCatName(''); loadCat(selectedCategory.id); }
    catch (err) { alert(err.response?.data?.message || 'Failed.'); }
  };

  const handleDeleteCat = async () => {
    if (!selectedCategory || !window.confirm(`Delete "${selectedCategory.name}" and all its products?`)) return;
    try { await api.delete(`/categories/${selectedCategory.id}`); setSelectedCategory(null); await loadCategories(); }
    catch (err) { alert(err.response?.data?.message || 'Delete failed.'); }
  };

  const getTotalQty = (p = []) => p.reduce((s, x) => s + Number(x.quantity || 0), 0);

  if (loading) return <Spinner />;

  return (
    <div style={{ animation:'ah-fadeUp 0.35s ease' }}>
      {/* Categories */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:20, flexWrap:'wrap', gap:14 }}>
        <div>
          <span className="ah-section-tag">Catalogue</span>
          <h2 style={{ fontFamily:"'Fraunces',serif", fontSize:22, fontWeight:900, color:'#1e1b4b', marginTop:4 }}>
            Categories <span style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:13, fontWeight:600, color:'#9ca3af' }}>{categories.length}</span>
          </h2>
        </div>
        <button className="ah-btn ah-btn-violet" onClick={() => setShowAddCat(true)}>+ Add Category</button>
      </div>

      <div style={{ display:'flex', flexWrap:'wrap', gap:12, marginBottom:36 }}>
        {categories.map(cat => (
          <div key={cat.id} onClick={() => loadCat(cat.id)} style={{ background: selectedCategory?.id===cat.id ? 'linear-gradient(135deg,#f5f3ff,#ede9fe)' : '#fff', border:`2px solid ${selectedCategory?.id===cat.id?'#6366f1':'#f0f0f0'}`, borderRadius:16, padding:'16px 24px', minWidth:140, textAlign:'center', cursor:'pointer', transition:'all 0.22s', boxShadow: selectedCategory?.id===cat.id?'0 8px 28px rgba(99,102,241,0.18)':'none' }}>
            <p style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:14, fontWeight:700, color: selectedCategory?.id===cat.id?'#4338ca':'#1e1b4b', margin:0 }}>{cat.name}</p>
          </div>
        ))}
        {categories.length === 0 && <p style={{ color:'#d1d5db', fontSize:14, padding:'16px 0' }}>No categories yet.</p>}
      </div>

      {selectedCategory && (
        <>
          <div className="ah-divider" />
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:24, flexWrap:'wrap', gap:14 }}>
            <div>
              <span className="ah-section-tag">Products</span>
              <h2 style={{ fontFamily:"'Fraunces',serif", fontSize:22, fontWeight:900, color:'#1e1b4b', marginTop:4 }}>{selectedCategory.name}</h2>
            </div>
            <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}>
              <button className="ah-btn ah-btn-amber" onClick={() => { setEditCatName(selectedCategory.name); setShowEditCat(true); }}>✏️ Edit</button>
              <button className="ah-btn ah-btn-red" onClick={handleDeleteCat}>🗑️ Delete</button>
              <button className="ah-btn ah-btn-violet" onClick={() => { setEditingProduct(null); setProductForm({ name:'', imageUrl:'', quantity:'', price:'', discount:'' }); setImagePreview(null); setShowProductForm(true); }}>+ Add Product</button>
            </div>
          </div>

          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))', gap:16, marginBottom:28 }}>
            {[
              { label:'Total Stock',   value: getTotalQty(selectedCategory.products) },
              { label:'Product Count', value: (selectedCategory.products||[]).length },
              { label:'Discount',      value: selectedCategory.discount || '—' },
            ].map(({ label, value }) => (
              <div key={label} className="ah-stat">
                <div className="ah-stat-label">{label}</div>
                <div className="ah-stat-value">{value}</div>
              </div>
            ))}
          </div>

          {(!selectedCategory.products || selectedCategory.products.length === 0) ? (
            <div className="ah-empty">
              <div style={{ fontSize:40, marginBottom:14 }}>📦</div>
              <p style={{ color:'#9ca3af', fontSize:14, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>No products yet. Click <strong style={{ color:'#6366f1' }}>Add Product</strong> to get started.</p>
            </div>
          ) : (
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))', gap:24 }}>
              {selectedCategory.products.map((product, i) => (
                <div key={product.id} className="ah-card" style={{ animation:`ah-fadeUp 0.4s ease ${i*0.05}s both` }}>
                  <div style={{ position:'relative', height:220, background:'#f8f7ff', overflow:'hidden' }}>
                    <img src={product.image||product.imageUrl||'https://via.placeholder.com/400x220?text=No+Image'} alt={product.name} onError={e=>e.target.src='https://via.placeholder.com/400x220?text=No+Image'} style={{ width:'100%', height:'100%', objectFit:'cover' }} />
                    {product.discount && (
                      <div style={{ position:'absolute', top:10, right:10, background:'linear-gradient(135deg,#f59e0b,#d97706)', color:'#fff', fontSize:12, fontWeight:800, padding:'5px 13px', borderRadius:25, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>
                        {product.discount} OFF
                      </div>
                    )}
                  </div>
                  <div style={{ padding:'18px' }}>
                    <p style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:16, fontWeight:800, color:'#1e1b4b', margin:'0 0 10px', lineHeight:1.3 }}>{product.name}</p>
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
                      <span style={{ fontSize:13, fontWeight:600, color:'#6b7280' }}>📦 Qty: {product.quantity}</span>
                      <span style={{ fontFamily:"'Fraunces',serif", fontSize:20, fontWeight:900, color:'#6366f1' }}>₹{Number(product.price).toLocaleString('en-IN')}</span>
                    </div>
                    <div style={{ display:'flex', gap:10 }}>
                      <button onClick={() => { setEditingProduct(product); setProductForm({ name:product.name, imageUrl:product.image||product.imageUrl||'', quantity:product.quantity, price:product.price, discount:product.discount||'' }); setImagePreview(product.image||product.imageUrl||null); setShowProductForm(true); }} style={{ flex:1, padding:'9px 0', fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:12, fontWeight:700, background:'#f5f3ff', color:'#6366f1', border:'1.5px solid #e0e7ff', borderRadius:10, cursor:'pointer' }}>✏️ Edit</button>
                      <button onClick={() => handleDeleteProduct(product.id, product.name)} style={{ flex:1, padding:'9px 0', fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:12, fontWeight:700, background:'#fff1f2', color:'#f43f5e', border:'1.5px solid #fecdd3', borderRadius:10, cursor:'pointer' }}>🗑️ Delete</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* Modals */}
      {showAddCat && (
        <div className="ah-overlay" onClick={() => setShowAddCat(false)}>
          <div className="ah-modal" onClick={e => e.stopPropagation()}>
            <button className="ah-modal-close" onClick={() => setShowAddCat(false)}>✕</button>
            <div className="ah-modal-title">New Category</div>
            <input className="ah-input" placeholder="Category name…" value={newCatName} onChange={e => setNewCatName(e.target.value)} autoFocus onKeyDown={e => e.key==='Enter' && handleAddCat()} />
            <button className="ah-btn ah-btn-violet" style={{ width:'100%', padding:'13px', fontSize:15, borderRadius:14 }} onClick={handleAddCat}>Add Category</button>
          </div>
        </div>
      )}

      {showEditCat && (
        <div className="ah-overlay" onClick={() => setShowEditCat(false)}>
          <div className="ah-modal" onClick={e => e.stopPropagation()}>
            <button className="ah-modal-close" onClick={() => setShowEditCat(false)}>✕</button>
            <div className="ah-modal-title">Edit Category</div>
            <input className="ah-input" value={editCatName} onChange={e => setEditCatName(e.target.value)} autoFocus onKeyDown={e => e.key==='Enter' && handleUpdateCat()} />
            <button className="ah-btn ah-btn-amber" style={{ width:'100%', padding:'13px', fontSize:15, borderRadius:14 }} onClick={handleUpdateCat}>Update Category</button>
          </div>
        </div>
      )}

      {showProductForm && (
        <div className="ah-overlay" onClick={() => setShowProductForm(false)}>
          <div className="ah-modal" onClick={e => e.stopPropagation()} style={{ maxWidth:460, maxHeight:'90vh', overflowY:'auto' }}>
            <button className="ah-modal-close" onClick={() => setShowProductForm(false)}>✕</button>
            <div className="ah-modal-title">{editingProduct ? 'Edit Product' : 'New Product'}</div>
            <form onSubmit={handleSaveProduct}>
              <div onClick={() => document.getElementById('ah-file-input').click()} style={{ marginBottom:16, borderRadius:14, overflow:'hidden', border: imagePreview?'none':'2px dashed #c7d2fe', background: imagePreview?'transparent':'#f5f3ff', cursor:'pointer', minHeight: imagePreview?'auto':110, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:8 }}>
                {imagePreview ? (
                  <div style={{ position:'relative' }}>
                    <img src={imagePreview} alt="preview" style={{ width:'100%', maxHeight:190, objectFit:'cover', borderRadius:12, display:'block' }} />
                    <div style={{ position:'absolute', inset:0, background:'rgba(99,102,241,0.5)', borderRadius:12, display:'flex', alignItems:'center', justifyContent:'center', opacity:0, transition:'opacity 0.2s' }} onMouseEnter={e=>e.currentTarget.style.opacity=1} onMouseLeave={e=>e.currentTarget.style.opacity=0}>
                      <span style={{ color:'#fff', fontFamily:"'Plus Jakarta Sans',sans-serif", fontWeight:700, fontSize:14 }}>🔄 Change Image</span>
                    </div>
                  </div>
                ) : (
                  <>
                    <span style={{ fontSize:30 }}>📸</span>
                    <span style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:13, fontWeight:600, color:'#818cf8' }}>Click to upload image</span>
                    <span style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:11, color:'#a5b4fc' }}>JPG, PNG, WEBP (Max 2MB)</span>
                  </>
                )}
              </div>
              <input id="ah-file-input" type="file" accept="image/*" style={{ display:'none' }} onChange={handleImageSelect} />
              {[
                { key:'name',     placeholder:'Product Name',        type:'text',   required:true  },
                { key:'quantity', placeholder:'Quantity',            type:'number', min:0, required:true  },
                { key:'price',    placeholder:'Price (₹)',           type:'number', min:0, step:1, required:true },
                { key:'discount', placeholder:'Discount (e.g. 15%)', type:'text' },
              ].map(({ key, ...rest }) => (
                <input key={key} className="ah-input" value={productForm[key]} onChange={e => setProductForm(f => ({ ...f, [key]:e.target.value }))} {...rest} />
              ))}
              <button type="submit" className="ah-btn ah-btn-violet" style={{ width:'100%', padding:'13px', fontSize:15, borderRadius:14 }}>
                {editingProduct ? 'Update Product' : 'Add Product'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
//  TAB 2 — USERS
// ═══════════════════════════════════════════════════════════════════════════════
function UsersTab() {
  const [users, setUsers]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch]   = useState('');

  const loadUsers = useCallback(async () => {
    try {
      setLoading(true);
      const res = await api.get('/users');
      setUsers(res.data.data || []);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadUsers(); }, [loadUsers]);

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete user "${name}"? This cannot be undone.`)) return;
    try { await api.delete(`/users/${id}`); setUsers(prev => prev.filter(u => u.id !== id)); }
    catch (err) { alert(err.response?.data?.message || 'Delete failed.'); }
  };

  const regularUsers = users
    .filter(u => u.role !== 'ADMIN')
    .filter(u =>
      !search ||
      u.fullName?.toLowerCase().includes(search.toLowerCase()) ||
      u.email?.toLowerCase().includes(search.toLowerCase()) ||
      u.phone?.includes(search)
    );

  const adminCount  = users.filter(u => u.role === 'ADMIN').length;

  if (loading) return <Spinner />;

  return (
    <div style={{ animation:'ah-fadeUp 0.35s ease' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:24, flexWrap:'wrap', gap:14 }}>
        <div>
          <span className="ah-section-tag">Manage</span>
          <h2 style={{ fontFamily:"'Fraunces',serif", fontSize:22, fontWeight:900, color:'#1e1b4b', marginTop:4 }}>
            Users <span style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:13, fontWeight:600, color:'#9ca3af' }}>{regularUsers.length} customers</span>
          </h2>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:10, background:'#fff', border:'1.5px solid #e5e7eb', borderRadius:12, padding:'10px 16px', minWidth:280 }}>
          <span style={{ color:'#9ca3af' }}>🔍</span>
          <input placeholder="Search by name, email or phone…" value={search} onChange={e => setSearch(e.target.value)}
            style={{ border:'none', outline:'none', fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:13, fontWeight:500, color:'#374151', flex:1, background:'transparent' }} />
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))', gap:16, marginBottom:28 }}>
        {[
          { label:'Total Users',  value: users.length },
          { label:'Customers',    value: users.filter(u=>u.role!=='ADMIN').length },
          { label:'Admins',       value: adminCount },
        ].map(({ label, value }) => (
          <div key={label} className="ah-stat"><div className="ah-stat-label">{label}</div><div className="ah-stat-value">{value}</div></div>
        ))}
      </div>

      {regularUsers.length === 0 ? (
        <div className="ah-empty">
          <div style={{ fontSize:40, marginBottom:14 }}>👤</div>
          <p style={{ color:'#9ca3af', fontSize:14, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>No customers found.</p>
        </div>
      ) : (
        <div className="ah-card">
          <table className="ah-table">
            <thead>
              <tr>
                <th>#</th><th>Name</th><th>Email</th><th>Phone</th><th>City</th><th>Joined</th><th>Action</th>
              </tr>
            </thead>
            <tbody>
              {regularUsers.map((u, i) => (
                <tr key={u.id}>
                  <td style={{ color:'#9ca3af', fontWeight:600 }}>{i + 1}</td>
                  <td>
                    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                      <div style={{ width:36, height:36, borderRadius:'50%', background:'linear-gradient(135deg,#6366f1,#8b5cf6)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:800, fontSize:14, flexShrink:0 }}>
                        {u.fullName?.charAt(0)?.toUpperCase() || 'U'}
                      </div>
                      <span style={{ fontWeight:700, color:'#1e1b4b' }}>{u.fullName}</span>
                    </div>
                  </td>
                  <td style={{ color:'#6b7280' }}>{u.email}</td>
                  <td style={{ color:'#6b7280' }}>{u.phone || '—'}</td>
                  <td style={{ color:'#6b7280' }}>{u.city || '—'}</td>
                  <td style={{ color:'#9ca3af', fontSize:12 }}>{u.createdAt ? new Date(u.createdAt).toLocaleDateString('en-IN') : '—'}</td>
                  <td>
                    <button onClick={() => handleDelete(u.id, u.fullName)}
                      style={{ background:'#fff1f2', color:'#f43f5e', border:'1.5px solid #fecdd3', borderRadius:10, padding:'7px 16px', fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:12, fontWeight:700, cursor:'pointer', transition:'all 0.2s' }}>
                      🗑️ Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
//  TAB 3 — ORDERS
// ═══════════════════════════════════════════════════════════════════════════════
function OrdersTab() {
  const [orders, setOrders]           = useState([]);
  const [loading, setLoading]         = useState(true);
  const [filter, setFilter]           = useState('ALL');
  const [search, setSearch]           = useState('');
  const [expandedOrder, setExpanded]  = useState(null);
  const [updating, setUpdating]       = useState(null);

  const loadOrders = useCallback(async () => {
    try {
      setLoading(true);
      const res = await api.get('/orders');
      const sorted = (res.data.data || []).sort((a, b) => new Date(b.orderedAt) - new Date(a.orderedAt));
      setOrders(sorted);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadOrders(); }, [loadOrders]);

  const handleStatusChange = async (orderId, newStatus) => {
    setUpdating(orderId);
    try {
      const res = await api.patch(`/orders/${orderId}/status`, { status: newStatus });
      const updated = res.data.data;
      setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: updated.status } : o));
    } catch (err) {
      alert(err.response?.data?.message || 'Status update failed.');
    } finally {
      setUpdating(null);
    }
  };

  const STATUSES = ['ALL', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED'];
  const counts = STATUSES.reduce((acc, s) => {
    acc[s] = s === 'ALL' ? orders.length : orders.filter(o => o.status === s).length;
    return acc;
  }, {});

  const filtered = orders.filter(o => {
    const mf = filter === 'ALL' || o.status === filter;
    const ms = !search || o.id?.toString().includes(search) || o.userName?.toLowerCase().includes(search.toLowerCase());
    return mf && ms;
  });

  const totalRevenue = orders.filter(o => o.status === 'DELIVERED').reduce((sum, o) => sum + Number(o.totalAmount || 0), 0);

  if (loading) return <Spinner />;

  return (
    <div style={{ animation:'ah-fadeUp 0.35s ease' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:24, flexWrap:'wrap', gap:14 }}>
        <div>
          <span className="ah-section-tag">Manage</span>
          <h2 style={{ fontFamily:"'Fraunces',serif", fontSize:22, fontWeight:900, color:'#1e1b4b', marginTop:4 }}>
            Orders <span style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:13, fontWeight:600, color:'#9ca3af' }}>{orders.length} total</span>
          </h2>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:10, background:'#fff', border:'1.5px solid #e5e7eb', borderRadius:12, padding:'10px 16px', minWidth:280 }}>
          <span style={{ color:'#9ca3af' }}>🔍</span>
          <input placeholder="Search by Order ID or customer…" value={search} onChange={e => setSearch(e.target.value)}
            style={{ border:'none', outline:'none', fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:13, fontWeight:500, color:'#374151', flex:1, background:'transparent' }} />
        </div>
      </div>

      {/* Stats */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(150px,1fr))', gap:16, marginBottom:28 }}>
        {[
          { label:'Total Orders',  value: counts.ALL },
          { label:'Processing',    value: counts.PROCESSING },
          { label:'Shipped',       value: counts.SHIPPED },
          { label:'Completed',     value: counts.DELIVERED },
          { label:'Revenue',       value: `₹${totalRevenue.toLocaleString('en-IN')}` },
        ].map(({ label, value }) => (
          <div key={label} className="ah-stat">
            <div className="ah-stat-label">{label}</div>
            <div className="ah-stat-value" style={{ fontSize: String(value).length > 8 ? 20 : 36 }}>{value}</div>
          </div>
        ))}
      </div>

      {/* Filter chips */}
      <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginBottom:24 }}>
        {[
          { key:'ALL',        label:'📋 All'          },
          { key:'PROCESSING', label:'⏳ Processing'   },
          { key:'SHIPPED',    label:'🚚 Shipped'      },
          { key:'DELIVERED',  label:'✅ Completed'    },
          { key:'CANCELLED',  label:'✕ Cancelled'    },
        ].map(({ key, label }) => (
          <button key={key} onClick={() => setFilter(key)}
            style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:12, fontWeight:700, border: filter===key?'2px solid #6366f1':'1.5px solid #e5e7eb', borderRadius:10, padding:'8px 16px', cursor:'pointer', background: filter===key?'#f0f0ff':'#fff', color: filter===key?'#4f46e5':'#6b7280', transition:'all 0.2s' }}>
            {label} <span style={{ marginLeft:5, background: filter===key?'#6366f1':'#f3f4f6', color: filter===key?'#fff':'#9ca3af', borderRadius:20, padding:'1px 8px', fontSize:11 }}>{counts[key]}</span>
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="ah-empty">
          <div style={{ fontSize:40, marginBottom:14 }}>🛒</div>
          <p style={{ color:'#9ca3af', fontSize:14, fontFamily:"'Plus Jakarta Sans',sans-serif" }}>No orders found.</p>
        </div>
      ) : (
        <div className="ah-card">
          <table className="ah-table">
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Items</th>
                <th>Total</th>
                <th>Payment</th>
                <th>Date</th>
                <th>Status</th>
                <th>Update Status</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(order => (
                <React.Fragment key={order.id}>
                  <tr style={{ cursor:'pointer' }} onClick={() => setExpanded(expandedOrder===order.id ? null : order.id)}>
                    <td style={{ fontWeight:800, color:'#4f46e5' }}>#{order.id}</td>
                    <td>
                      <div style={{ display:'flex', alignItems:'center', gap:9 }}>
                        <div style={{ width:32, height:32, borderRadius:'50%', background:'linear-gradient(135deg,#6366f1,#8b5cf6)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:800, fontSize:13, flexShrink:0 }}>
                          {order.userName?.charAt(0)?.toUpperCase() || 'U'}
                        </div>
                        <span style={{ fontWeight:700, color:'#1e1b4b' }}>{order.userName}</span>
                      </div>
                    </td>
                    <td style={{ color:'#6b7280' }}>{order.items?.length || 0} item{(order.items?.length||0)!==1?'s':''}</td>
                    <td style={{ fontFamily:"'Fraunces',serif", fontWeight:900, color:'#6366f1', fontSize:16 }}>₹{Number(order.totalAmount).toLocaleString('en-IN')}</td>
                    <td style={{ color:'#6b7280', fontSize:12 }}>{order.paymentMethod || '—'}</td>
                    <td style={{ color:'#9ca3af', fontSize:12 }}>{order.orderedAt ? new Date(order.orderedAt).toLocaleDateString('en-IN') : '—'}</td>
                    <td><StatusBadge status={order.status} /></td>
                    <td onClick={e => e.stopPropagation()}>
                      {updating === order.id ? (
                        <div style={{ width:20, height:20, border:'2px solid #e0e7ff', borderTop:'2px solid #6366f1', borderRadius:'50%', animation:'ah-spin 0.7s linear infinite' }} />
                      ) : (
                        <select className="ah-status-select" value={order.status}
                          onChange={e => handleStatusChange(order.id, e.target.value)}
                          disabled={order.status === 'DELIVERED' || order.status === 'CANCELLED'}
                          title={order.status==='DELIVERED'||order.status==='CANCELLED'?'Status is final':'Change order status'}
                        >
                          <option value="PROCESSING">⏳ Processing</option>
                          <option value="SHIPPED">🚚 Shipped</option>
                          <option value="DELIVERED">✅ Mark Completed</option>
                          <option value="CANCELLED">✕ Cancelled</option>
                        </select>
                      )}
                    </td>
                  </tr>

                  {/* Expandable items */}
                  {expandedOrder === order.id && (
                    <tr>
                      <td colSpan={8} style={{ background:'#fafafe', padding:'0 20px 16px' }}>
                        <div style={{ paddingTop:14 }}>
                          <p style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:11, fontWeight:700, color:'#9ca3af', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:10 }}>Order Items</p>
                          {order.items?.map((item, i) => (
                            <div key={i} className="ah-order-item">
                              <img src={item.image||'https://via.placeholder.com/48?text=?'} alt={item.name} onError={e=>e.target.src='https://via.placeholder.com/48?text=?'} />
                              <div style={{ flex:1 }}>
                                <p style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontWeight:700, fontSize:14, color:'#1e1b4b', margin:0 }}>{item.name}</p>
                                <p style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:12, color:'#9ca3af', margin:'2px 0 0' }}>Qty: {item.quantity}</p>
                              </div>
                              <span style={{ fontFamily:"'Fraunces',serif", fontWeight:900, color:'#6366f1', fontSize:15 }}>
                                ₹{Number(item.subtotal || (item.unitPrice * item.quantity)).toLocaleString('en-IN')}
                              </span>
                            </div>
                          ))}
                          <div style={{ marginTop:12, paddingTop:12, borderTop:'1.5px solid #e0e7ff', display:'flex', justifyContent:'flex-end', alignItems:'center', gap:16 }}>
                            <span style={{ fontFamily:"'Plus Jakarta Sans',sans-serif", fontSize:13, fontWeight:700, color:'#6b7280' }}>Order Total:</span>
                            <span style={{ fontFamily:"'Fraunces',serif", fontWeight:900, fontSize:20, color:'#4f46e5' }}>₹{Number(order.totalAmount).toLocaleString('en-IN')}</span>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
//  MAIN — AdminHome shell
// ═══════════════════════════════════════════════════════════════════════════════
function AdminHome() {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const [activeTab, setActiveTab] = useState('products');

  const handleLogout = async () => { await logout(); navigate('/login'); };

  const TABS = [
    { id:'products', icon:'📦', label:'Products' },
    { id:'users',    icon:'👥', label:'Users'    },
    { id:'orders',   icon:'🛒', label:'Orders'   },
  ];

  const PAGE_META = {
    products: { title:'📦 Product Manager',    sub:'Add, edit and delete categories & products' },
    users:    { title:'👥 User Manager',       sub:'View and manage registered customers' },
    orders:   { title:'🛒 Order Manager',      sub:'Track orders — marking Completed automatically reduces product stock' },
  };

  return (
    <div style={{ minHeight:'100vh', background:'#f8f7ff', fontFamily:"'Plus Jakarta Sans',sans-serif" }}>

      {/* Topbar */}
      <div className="ah-topbar">
        <div className="ah-brand">
          <div className="ah-brand-icon">🛍️</div>
          <span className="ah-brand-name">ShopAdmin</span>
        </div>

        {/* Tab switcher */}
        <div className="ah-tabs">
          {TABS.map(t => (
            <button key={t.id} className={`ah-tab${activeTab===t.id?' active':''}`} onClick={() => setActiveTab(t.id)}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        <div style={{ display:'flex', gap:10 }}>
          <button className="ah-btn ah-btn-ghost" onClick={() => navigate('/AdminProfile')}>👤 Profile</button>
          <button className="ah-btn ah-btn-red"   onClick={handleLogout}>🚪 Logout</button>
        </div>
      </div>

      {/* Content */}
      <div style={{ maxWidth:1320, margin:'0 auto', padding:'44px 32px 80px' }}>
        <div style={{ marginBottom:40 }}>
          <h1 style={{ fontFamily:"'Fraunces',serif", fontSize:40, fontWeight:900, color:'#1e1b4b', letterSpacing:'-0.03em', lineHeight:1.1, marginBottom:6 }}>
            {PAGE_META[activeTab].title}
          </h1>
          <p style={{ color:'#9ca3af', fontSize:14, fontWeight:500 }}>{PAGE_META[activeTab].sub}</p>
        </div>

        {activeTab === 'products' && <ProductsTab />}
        {activeTab === 'users'    && <UsersTab />}
        {activeTab === 'orders'   && <OrdersTab />}
      </div>
    </div>
  );
}

export default AdminHome;