import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

const products = [
  { id: 1, name: "Air Max Pro", price: "₹4,299", rating: 5, emoji: "👟", color: "#1a1a2e" },
  { id: 2, name: "Smart Watch", price: "₹8,999", rating: 4, emoji: "⌚", color: "#16213e" },
  { id: 3, name: "Beats Pro", price: "₹12,499", rating: 5, emoji: "🎧", color: "#0f3460" },
  { id: 4, name: "Galaxy S25", price: "₹79,999", rating: 4, emoji: "📱", color: "#1a1a2e" },
];

const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Sans:ital,wght@0,300;0,400;1,300&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg:rgb(197, 201, 202);
    --surface: #111111;
    --card: #161616;
    --accent: #ff3d00;
    --accent2: #ff6d00;
    --accent-glow: rgba(255, 61, 0, 0.25);
    --text: #f0ece4;
    --muted: #6b6b6b;
    --border: rgba(255,255,255,0.07);
  }

  body { background: var(--bg); color: var(--text); font-family: 'DM Sans', sans-serif; overflow-x: hidden; }

  .lp-root {
    min-height: 100vh;
    background: var(--bg);
    position: relative;
    overflow: hidden;
  }

  /* === NOISE TEXTURE OVERLAY === */
  .lp-root::before {
    content: '';
    position: fixed;
    inset: 0;
    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
    pointer-events: none;
    z-index: 0;
    opacity: 0.6;
  }

  /* === AMBIENT GLOW BG === */
  .bg-glow {
    position: fixed;
    border-radius: 50%;
    filter: blur(120px);
    pointer-events: none;
    z-index: 0;
  }
  .bg-glow-1 {
    width: 600px; height: 600px;
    background: radial-gradient(circle, rgba(255,61,0,0.12), transparent 70%);
    top: -200px; right: -100px;
  }
  .bg-glow-2 {
    width: 400px; height: 400px;
    background: radial-gradient(circle, rgba(255,109,0,0.08), transparent 70%);
    bottom: 100px; left: -100px;
  }

  /* === NAV === */
  nav {
    position: fixed;
    top: 0; left: 0; right: 0;
    z-index: 100;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20px 48px;
    background: rgba(10,10,10,0.7);
    backdrop-filter: blur(20px);
    border-bottom: 1px solid var(--border);
    transition: all 0.3s ease;
  }
  nav.scrolled {
    padding: 14px 48px;
    background: rgba(10,10,10,0.95);
  }

  .nav-logo {
    display: flex;
    align-items: center;
    gap: 10px;
    font-family: 'Syne', sans-serif;
    font-weight: 800;
    font-size: 1.4rem;
    letter-spacing: -0.5px;
    color: var(--text);
    text-decoration: none;
  }
  .nav-logo-icon {
    width: 36px; height: 36px;
    background: var(--accent);
    border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.1rem;
    box-shadow: 0 0 20px var(--accent-glow);
  }

  .nav-actions { display: flex; gap: 12px; align-items: center; }

  .btn-ghost {
  background: linear-gradient(90deg, rgb(213, 14, 163), rgb(255, 94, 0));
  border: none;
  color: #fff;
  padding: 9px 22px;
  border-radius: 100px;
  font-family: 'DM Sans', sans-serif;
  font-size: 0.875rem;
  cursor: pointer;
  transition: all 0.3s ease;
  letter-spacing: 0.01em;
  box-shadow: 0px 4px 12px rgba(213, 14, 163, 0.3);
}

.btn-ghost:hover {
  transform: translateY(-2px) scale(1.05);
  box-shadow: 0px 6px 20px rgba(255, 94, 0, 0.5);
}

 .btn-primary {
  background: linear-gradient(90deg, rgb(255, 94, 0), rgb(255, 42, 0));
  border: none;
  color: #fff;
  padding: 10px 24px;
  border-radius: 100px;
  font-family: 'DM Sans', sans-serif;
  font-size: 0.875rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 18px rgba(255, 94, 0, 0.4);
  display: flex;
  align-items: center;
  gap: 6px;
  position: relative;
  overflow: hidden;
}
  .btn-primary:hover {
  transform: translateY(-2px) scale(1.05);
  box-shadow: 0 8px 28px rgba(255, 61, 0, 0.6);
}
  .btn-primary::before {
  content: '';
  position: absolute;
  top: 0;
  left: -75%;
  width: 50%;
  height: 100%;
  background: linear-gradient(120deg, transparent, rgba(255,255,255,0.6), transparent);
  transform: skewX(-20deg);
}

.btn-primary:hover::before {
  left: 130%;
  transition: 0.6s;
}
  .btn-primary:active { transform: translateY(0); }

  /* === SALE BADGE === */

  .sale-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 6px 16px;
    border: 1px solid rgba(255,61,0,0.35);
    border-radius: 100px;
    font-size: 0.72rem;
    font-weight: 500;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: var(--accent);
    background: rgba(255,61,0,0.08);
    margin-bottom: 32px;
    animation: fadeInUp 0.6s ease both;
  }
  .sale-dot {
    width: 6px; height: 6px;
    border-radius: 50%;
    background: var(--accent);
    animation: pulse 1.5s ease infinite;
  }
  @keyframes pulse {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.5; transform: scale(0.8); }
  }

  /* === HERO === */
  .hero {
    position: relative;
    z-index: 1;
    min-height: 100vh;
    display: grid;
    grid-template-columns: 1fr 1fr;
    align-items: center;
    padding: 0 48px;
    padding-top: 80px;
    gap: 48px;
    max-width: 1400px;
    margin: 0 auto;
  }

  .hero-left { padding-top: 40px; }

  .hero-title {
    font-family: 'Syne', sans-serif;
    font-weight: 800;
    font-size: clamp(3rem, 5vw, 5.5rem);
    line-height: 0.92;
    letter-spacing: -0.03em;
    margin-bottom: 28px;
  }
  /* Word-fall: each word drops in from above */
  .hero-title .word {
    display: block;
    overflow: hidden;
    line-height: 1.0;
  }
  .hero-title .word-inner {
    display: inline-block;
    animation: wordFall 0.75s cubic-bezier(0.22, 1, 0.36, 1) both;
  }
  .hero-title .word-1 .word-inner { animation-delay: 0.05s; color: black; }
  .hero-title .word-2 .word-inner { animation-delay: 0.2s;  color: black; }
  .hero-title .word-3 .word-inner {
    animation-delay: 0.35s;
    background: linear-gradient(135deg, var(--accent), var(--accent2));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }
  .hero-title .word-4 .word-inner {
    animation-delay: 0.5s;
    background: linear-gradient(135deg, var(--accent2), #ffab00);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }
  @keyframes wordFall {
    from { opacity: 0; transform: translateY(-60px) skewY(-6deg); }
    to   { opacity: 1; transform: translateY(0)     skewY(0deg); }
  }

  .hero-desc {
    font-size: 1.05rem;
    line-height: 1.7;
    color: var(--muted);
    max-width: 420px;
    margin-bottom: 40px;
    animation: fadeInUp 0.7s 0.5s ease both;
  }

  .hero-cta {
    display: flex;
    gap: 14px;
    align-items: center;
    animation: fadeInUp 0.7s 0.6s ease both;
  }

  .btn-cta {
    background: var(--accent);
    border: none;
    color: #fff;
    padding: 14px 32px;
    border-radius: 100px;
    font-family: 'DM Sans', sans-serif;
    font-size: 1rem;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.25s ease;
    box-shadow: 0 0 40px var(--accent-glow), 0 4px 20px rgba(255,61,0,0.3);
    display: flex; align-items: center; gap: 10px;
  }
  .btn-cta:hover {
    transform: translateY(-2px);
    box-shadow: 0 0 60px rgba(255,61,0,0.4), 0 8px 30px rgba(255,61,0,0.35);
  }

  .btn-outline-cta {
    background: rgb(233, 126, 13);
    border: 1px solid rgba(255,255,255,0.15);
    color: var(--text);
    padding: 14px 28px;
    border-radius: 100px;
    font-family: 'DM Sans', sans-serif;
    font-size: 1rem;
    cursor: pointer;
    transition: all 0.25s ease;
  }
  .btn-outline-cta:hover {
    border-color: rgba(255,255,255,0.35);
    background: rgba(206, 121, 72, 0.9);
  }

  /* === PRODUCT GRID === */
  .hero-right {
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-template-rows: auto auto;
    gap: 16px;
    padding: 20px 0;
    align-self: center;
    animation: fadeInRight 0.8s 0.3s ease both;
  }

  .product-card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 20px;
    padding: 24px;
    position: relative;
    overflow: hidden;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.23, 1, 0.32, 1);
  }
  .product-card::before {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(255,255,255,0.03), transparent);
    border-radius: 20px;
  }
  .product-card:hover {
    transform: translateY(-6px) scale(1.02);
    border-color: rgba(255,61,0,0.3);
    box-shadow: 0 20px 60px rgba(0,0,0,0.5), 0 0 30px var(--accent-glow);
  }

  /* Floating up-down animation per card */
  .product-card:nth-child(1) { animation: floatA 3.5s ease-in-out infinite; }
  .product-card:nth-child(2) { animation: floatB 4s   ease-in-out infinite; margin-top: 32px; }
  .product-card:nth-child(3) { animation: floatC 3.8s ease-in-out infinite; }
  .product-card:nth-child(4) { animation: floatA 4.2s ease-in-out infinite; margin-top: -32px; }

  @keyframes floatA {
    0%, 100% { transform: translateY(0px); }
    50%       { transform: translateY(-10px); }
  }
  @keyframes floatB {
    0%, 100% { transform: translateY(-10px); }
    50%       { transform: translateY(0px); }
  }
  @keyframes floatC {
    0%, 100% { transform: translateY(-5px); }
    50%       { transform: translateY(8px); }
  }

  .product-emoji {
    font-size: 2.4rem;
    margin-bottom: 16px;
    display: block;
    filter: drop-shadow(0 4px 12px rgba(0,0,0,0.3));
  }

  .product-name {
    font-family: 'Syne', sans-serif;
    font-weight: 700;
    font-size: 0.95rem;
    color: var(--text);
    margin-bottom: 6px;
  }

  .product-price {
    font-size: 0.9rem;
    color: var(--accent);
    font-weight: 500;
    margin-bottom: 10px;
  }

  .stars {
    display: flex;
    gap: 2px;
  }
  .star { font-size: 0.65rem; color: #ffd600; }
  .star.empty { color: var(--muted); }



  /* === KEYFRAMES === */
  @keyframes fadeInUp {
    from { opacity: 0; transform: translateY(24px); }
    to { opacity: 1; transform: translateY(0); }
  }
  @keyframes fadeInRight {
    from { opacity: 0; transform: translateX(32px); }
    to { opacity: 1; transform: translateX(0); }
  }
  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }

  /* === CURSOR GLOW === */
  .cursor-glow {
    position: fixed;
    width: 400px; height: 400px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(255,61,0,0.06), transparent 60%);
    pointer-events: none;
    z-index: 0;
    transform: translate(-50%, -50%);
    transition: opacity 0.3s ease;
  }

  /* === RESPONSIVE === */
  @media (max-width: 900px) {
    nav { padding: 16px 24px; }
    .hero {
      grid-template-columns: 1fr;
      padding: 100px 24px 48px;
      text-align: center;
    }
    .hero-desc { margin: 0 auto 32px; }
    .hero-cta { justify-content: center; }
    .hero-right { max-width: 380px; margin: 0 auto; }
    .stats-bar { gap: 40px; padding: 24px; flex-wrap: wrap; }
  }
`;

export default function LandingPage() {
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);
  const cursorRef = useRef(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const onMouseMove = (e) => {
      if (cursorRef.current) {
        cursorRef.current.style.left = e.clientX + "px";
        cursorRef.current.style.top = e.clientY + "px";
      }
    };
    window.addEventListener("mousemove", onMouseMove);
    return () => window.removeEventListener("mousemove", onMouseMove);
  }, []);

  return (
    <>
      <style>{styles}</style>
      <div className="lp-root">
        {/* Cursor glow */}
        <div className="cursor-glow" ref={cursorRef} />

        {/* Ambient glows */}
        <div className="bg-glow bg-glow-1" />
        <div className="bg-glow bg-glow-2" />

        {/* NAV */}
        <nav className={scrolled ? "scrolled" : ""}>
          <a className="nav-logo" href="/">
            <div className="nav-logo-icon">🛒</div>
            Shopzy
          </a>
          <div className="nav-actions">
            <button className="btn-ghost" onClick={() => navigate("/login")}>
              Log in
            </button>
            <button className="btn-primary" onClick={() => navigate("/signup")}>
              Sign up →
            </button>
          </div>
        </nav>

        {/* HERO */}
        <section className="hero">
          <div className="hero-left">
            <div className="sale-badge">
              <span className="sale-dot" />
              New Season Sale — Up to 70% Off
            </div>

            <h1 className="hero-title">
              <span className="word word-1"><span className="word-inner">Shop</span></span>
              <span className="word word-2"><span className="word-inner">Smart,</span></span>
              <span className="word word-3"><span className="word-inner">Live</span></span>
              <span className="word word-4"><span className="word-inner">Better.</span></span>
            </h1>

            <p className="hero-desc">
              Discover millions of products from top brands worldwide. Fast
              delivery, easy returns, and unbeatable prices — all in one place.
            </p>

            <div className="hero-cta">
              <button className="btn-cta" onClick={() => navigate("/signup")}>
                Start Shopping <span>→</span>
              </button>
              
            </div>
          </div>

          <div className="hero-right">
            {products.map((p) => (
              <div className="product-card" key={p.id}>
                <span className="product-emoji">{p.emoji}</span>
                <div className="product-name">{p.name}</div>
                <div className="product-price">{p.price}</div>
                <div className="stars">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <span
                      key={s}
                      className={`star${s <= p.rating ? "" : " empty"}`}
                    >
                      ★
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        
      </div>
    </>
  );
}
