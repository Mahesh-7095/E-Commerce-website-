
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';

const UserHome = () => {
  const navigate = useNavigate();
  const { addToCart, getCartCount } = useCart();
  const { user, logout } = useAuth();

  const [products, setProducts]               = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [categories, setCategories]           = useState(['All']);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [loading, setLoading]                 = useState(true);
  const [notification, setNotification]       = useState({ show: false, message: '' });
  const [sortBy, setSortBy]                   = useState('default');
  const [searchTerm, setSearchTerm]           = useState('');

  // ── Guard: redirect admin away ──────────────────────────────────────────
  useEffect(() => {
    if (user?.role === 'ADMIN') navigate('/admin-home');
  }, [user, navigate]);

  // ── Fetch products and categories ───────────────────────────────────────
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);

        const productsRes = await api.get('/products');
        const productsList = productsRes.data.data || [];
        setProducts(productsList.map(p => ({ ...p, image: p.image || p.imageUrl })));

        const categoriesRes = await api.get('/categories');
        const adminCategories = categoriesRes.data.data || [];
        setCategories(adminCategories.length > 0
          ? ['All', ...adminCategories.map(cat => cat.name)]
          : ['All']
        );
      } catch (error) {
        console.error('Error fetching data:', error);
        setProducts([]);
        setCategories(['All']);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  // ── Filter + sort ────────────────────────────────────────────────────────
  useEffect(() => {
    let list = selectedCategory === 'All'
      ? [...products]
      : products.filter(p => p.category === selectedCategory);

    if (searchTerm) {
      list = list.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));
    }
    if (sortBy === 'priceLow')  list.sort((a, b) => a.price - b.price);
    if (sortBy === 'priceHigh') list.sort((a, b) => b.price - a.price);
    if (sortBy === 'discount')  list.sort((a, b) => (parseInt(b.discount) || 0) - (parseInt(a.discount) || 0));

    setFilteredProducts(list);
  }, [selectedCategory, products, sortBy, searchTerm]);

  const handleAddToCart = (product) => {
    addToCart(product);
    setNotification({ show: true, message: `${product.name} added to cart!` });
    setTimeout(() => setNotification({ show: false, message: '' }), 3000);
  };

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const clearSearch = () => setSearchTerm('');

  if (loading) {
    return (
      <div style={loadingContainer}>
        <div style={loadingSpinner}></div>
        <div style={loadingText}>Loading products...</div>
      </div>
    );
  }

  return (
    <div style={pageContainer}>
      {/* Cart Notification */}
      {notification.show && (
        <div style={cartNotification}>
          <span>{notification.message}</span>
          <button onClick={() => setNotification({ show: false })} style={notificationClose}>×</button>
        </div>
      )}

      {/* Top bar */}
      <div style={topBar}>
        <span>Shopzy</span>
        <span>Get 50% Off on Selected Items | Shopzy</span>
        <div style={topBarRight}>
          {user && (
            <button onClick={handleLogout} style={logoutBtn}>
              Logout ({user.fullName?.split(' ')[0]})
            </button>
          )}
        </div>
      </div>

      {/* Navbar */}
      <header style={header}>
        <div style={headerContent}>
          <div style={logo} onClick={() => navigate('/user-dashboard')}>
            🛒 <span style={logoText}>Shopzy</span>
          </div>
          <div style={headerRight}>
            <div style={searchContainer}>
              <input
                type="text"
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                style={searchInput}
              />
              {searchTerm && (
                <button onClick={clearSearch} style={clearButton}>×</button>
              )}
              <button style={searchButton}>🔍</button>
            </div>
            <button style={iconBtn} onClick={() => navigate('/user-dashboard')}>👤</button>
            <button style={iconBtn} onClick={() => navigate('/cart')}>🛒 ({getCartCount()})</button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section style={heroSection}>
        <div style={heroContent}>
          <div style={heroLeft}>
            <h1 style={heroTitle}>Grab Upto 50% Off On Selected Products</h1>
            <button style={heroButton}>Shopzy</button>
          </div>
          <div style={heroRight}>
            <img
              src="https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=300&fit=crop"
              alt="Shopping"
              style={heroImage}
            />
          </div>
        </div>
      </section>

      {/* Filter Bar */}
      <div style={filterContainer}>
        <div style={categoryList}>
          {categories.map((cat) => (
            <button
              key={cat}
              style={selectedCategory === cat ? categoryActive : categoryBtn}
              onClick={() => setSelectedCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
        <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} style={sortSelect}>
          <option value="default">Sort by</option>
          <option value="priceLow">Price: Low to High</option>
          <option value="priceHigh">Price: High to Low</option>
          <option value="discount">Discount</option>
        </select>
      </div>

      {/* Products Grid */}
      <section style={productsSection}>
        <h2 style={sectionHeading}>Products For You!</h2>
        {filteredProducts.length === 0 ? (
          <div style={emptyState}>
            <p>No products found in this category.</p>
          </div>
        ) : (
          <div style={productsGrid}>
            {filteredProducts.map((product) => (
              <div key={product.id} style={productCard}>
                <div style={productImageWrapper}>
                  <img src={product.image} alt={product.name} style={productImage} />
                  {product.discount && (
                    <div style={discountTag}>
                      <span>{product.discount} OFF</span>
                    </div>
                  )}
                </div>
                <h3 style={productTitle}>{product.name}</h3>
                <p style={productPrice}>₹{Number(product.price).toLocaleString('en-IN')}</p>
                <button style={cartButton} onClick={() => handleAddToCart(product)}>
                  Add to Cart
                </button>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};

// ── Styles ──────────────────────────────────────────────────────────────────
const loadingContainer = { display:'flex', flexDirection:'column', justifyContent:'center', alignItems:'center', height:'100vh', background:'linear-gradient(135deg, #001f4d, #4fc3f7)' };
const loadingSpinner   = { width:'50px', height:'50px', border:'5px solid rgba(255,255,255,0.3)', borderRadius:'50%', borderTopColor:'white', animation:'spin 1s ease-in-out infinite' };
const loadingText      = { color:'white', fontSize:'20px', marginTop:'20px', fontWeight:'bold' };
const pageContainer    = { fontFamily:"'Poppins', sans-serif", background:'linear-gradient(135deg, #001f4d, #4fc3f7)', minHeight:'100vh' };
const topBar           = { background:'linear-gradient(90deg, #001f4d, #4fc3f7)', color:'white', padding:'10px 20px', display:'flex', justifyContent:'space-between', alignItems:'center', fontSize:'13px' };
const topBarRight      = { display:'flex', alignItems:'center', gap:'15px' };
const logoutBtn        = { background:'transparent', color:'white', border:'1px solid white', padding:'5px 10px', borderRadius:'4px', cursor:'pointer', fontSize:'12px' };
const header           = { backgroundColor:'white', padding:'15px 20px', boxShadow:'0 2px 8px rgba(0,0,0,0.1)' };
const headerContent    = { display:'flex', justifyContent:'space-between', alignItems:'center', maxWidth:'1200px', margin:'0 auto' };
const logo             = { fontSize:'24px', fontWeight:'bold', cursor:'pointer' };
const logoText         = { color:'#001f4d' };
const headerRight      = { display:'flex', alignItems:'center', gap:'20px' };
const searchContainer  = { display:'flex', border:'1px solid #ddd', borderRadius:'25px', overflow:'hidden', alignItems:'center', backgroundColor:'white' };
const searchInput      = { border:'none', padding:'8px 15px', outline:'none', width:'250px', fontSize:'14px' };
const clearButton      = { background:'none', border:'none', color:'#999', fontSize:'18px', cursor:'pointer', padding:'0 5px', display:'flex', alignItems:'center', justifyContent:'center' };
const searchButton     = { background:'linear-gradient(90deg, #001f4d, #4fc3f7)', color:'white', border:'none', padding:'8px 15px', cursor:'pointer' };
const iconBtn          = { background:'none', border:'none', fontSize:'20px', cursor:'pointer', padding:'5px 10px' };
const heroSection      = { backgroundColor:'#F5F5DC', borderRadius:'20px', padding:'40px', margin:'30px auto', maxWidth:'1200px' };
const heroContent      = { display:'flex', alignItems:'center', gap:'40px' };
const heroLeft         = { flex:1 };
const heroTitle        = { fontSize:'42px', fontWeight:'bold', color:'#333', marginBottom:'20px', lineHeight:'1.2' };
const heroButton       = { background:'linear-gradient(90deg, #001f4d, #4fc3f7)', color:'white', border:'none', padding:'12px 30px', borderRadius:'25px', fontSize:'16px', fontWeight:'bold', cursor:'pointer' };
const heroRight        = { flex:1 };
const heroImage        = { width:'100%', borderRadius:'20px' };
const filterContainer  = { display:'flex', justifyContent:'space-between', alignItems:'center', padding:'20px', maxWidth:'1200px', margin:'0 auto' };
const categoryList     = { display:'flex', gap:'10px', flexWrap:'wrap' };
const categoryBtn      = { backgroundColor:'white', padding:'8px 20px', borderRadius:'20px', border:'1px solid #ddd', cursor:'pointer', fontSize:'14px', transition:'all 0.3s' };
const categoryActive   = { backgroundColor:'#001f4d', color:'white', padding:'8px 20px', borderRadius:'20px', border:'none', cursor:'pointer', fontSize:'14px' };
const sortSelect       = { padding:'8px 15px', border:'1px solid #ddd', borderRadius:'5px', backgroundColor:'white', cursor:'pointer' };
const productsSection  = { maxWidth:'1200px', margin:'0 auto', padding:'0 20px 50px' };
const sectionHeading   = { fontSize:'32px', fontWeight:'bold', color:'white', textAlign:'center', marginBottom:'40px' };
const productsGrid     = { display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(320px, 1fr))', gap:'35px' };
const productCard      = { backgroundColor:'white', borderRadius:'20px', padding:'25px', boxShadow:'0 8px 20px rgba(0,0,0,0.15)', textAlign:'center', transition:'transform 0.3s, box-shadow 0.3s', cursor:'pointer' };
const productImageWrapper = { position:'relative', width:'100%', height:'280px', marginBottom:'20px', borderRadius:'15px', overflow:'hidden', backgroundColor:'#f5f5f5' };
const productImage     = { width:'100%', height:'100%', objectFit:'cover', transition:'transform 0.3s ease' };
const discountTag      = { position:'absolute', top:'12px', right:'12px', background:'linear-gradient(135deg, #ff6b6b, #ee5a24)', color:'white', padding:'6px 14px', borderRadius:'25px', fontSize:'13px', fontWeight:'bold', boxShadow:'0 2px 8px rgba(0,0,0,0.2)' };
const productTitle     = { fontSize:'20px', fontWeight:'bold', color:'#333', marginBottom:'12px', minHeight:'60px' };
const productPrice     = { fontSize:'26px', fontWeight:'bold', color:'#001f4d', marginBottom:'20px' };
const cartButton       = { background:'linear-gradient(90deg, #001f4d, #4fc3f7)', color:'white', border:'none', padding:'14px 20px', borderRadius:'30px', fontSize:'16px', fontWeight:'bold', cursor:'pointer', width:'100%', transition:'transform 0.2s, box-shadow 0.2s' };
const cartNotification = { position:'fixed', top:'20px', right:'20px', backgroundColor:'#4CAF50', color:'white', padding:'12px 20px', borderRadius:'8px', boxShadow:'0 4px 12px rgba(0,0,0,0.2)', zIndex:1000, display:'flex', alignItems:'center', gap:'15px' };
const notificationClose = { background:'none', border:'none', color:'white', fontSize:'20px', cursor:'pointer' };
const emptyState       = { textAlign:'center', color:'white', fontSize:'18px', padding:'50px' };

// Spinner animation
const spinStyle = document.createElement('style');
spinStyle.textContent = `
  @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
  .product-card:hover { transform: translateY(-8px); box-shadow: 0 15px 35px rgba(0,0,0,0.2); }
  .product-card:hover img { transform: scale(1.05); }
`;
if (!document.getElementById('userhome-spin')) {
  spinStyle.id = 'userhome-spin';
  document.head.appendChild(spinStyle);
}

export default UserHome;