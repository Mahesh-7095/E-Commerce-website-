import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';

const Payment = () => {
  const navigate = useNavigate();
  const { cart, getTotal, clearCart } = useCart();
  const { user } = useAuth();

  const [paymentDetails, setPaymentDetails] = useState({ 
    cardNumber: '', 
    expiry: '', 
    cvv: '', 
    name: '' 
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('card');

  const handleChange = (e) =>
    setPaymentDetails({ ...paymentDetails, [e.target.name]: e.target.value });

  const formatCardNumber = (value) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || '';
    const parts = [];
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    if (parts.length) {
      return parts.join(' ');
    } else {
      return value;
    }
  };

  const formatExpiry = (value) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return v.substring(0, 2) + (v.length > 2 ? '/' + v.substring(2, 4) : '');
    }
    return v;
  };

  const validateExpiry = (expiry) => {
    if (!expiry || expiry.length !== 5) {
      return false;
    }
    
    const [month, year] = expiry.split('/');
    const monthNum = parseInt(month, 10);
    const yearNum = parseInt(year, 10);
    const currentYear = new Date().getFullYear() % 100; // Get last 2 digits of current year
    const currentMonth = new Date().getMonth() + 1;
    
    // Check if month is between 1 and 12
    if (monthNum < 1 || monthNum > 12) {
      return false;
    }
    
    // Check if card is expired
    if (yearNum < currentYear) {
      return false;
    }
    
    if (yearNum === currentYear && monthNum < currentMonth) {
      return false;
    }
    
    return true;
  };

  const handleCardInput = (e) => {
    const { name, value } = e.target;
    if (name === 'cardNumber') {
      setPaymentDetails({ ...paymentDetails, [name]: formatCardNumber(value) });
    } else if (name === 'expiry') {
      const formattedValue = formatExpiry(value);
      setPaymentDetails({ ...paymentDetails, [name]: formattedValue });
    } else {
      setPaymentDetails({ ...paymentDetails, [name]: value });
    }
  };

  const handlePayment = async (e) => {
    e.preventDefault();
    
    if (paymentMethod === 'card') {
      // Basic validation
      const cardNumberClean = paymentDetails.cardNumber.replace(/\s/g, '');
      if (cardNumberClean.length < 16) {
        setError('Please enter a valid 16-digit card number');
        return;
      }
      
      if (paymentDetails.expiry.length !== 5) {
        setError('Please enter a valid expiry date (MM/YY)');
        return;
      }
      
      // Validate expiry date properly
      if (!validateExpiry(paymentDetails.expiry)) {
        setError('Invalid expiry date. Please check the month and year.');
        return;
      }
      
      if (paymentDetails.cvv.length < 3) {
        setError('Please enter a valid CVV');
        return;
      }
      
      if (!paymentDetails.name.trim()) {
        setError('Please enter cardholder name');
        return;
      }
    }
    
    setError('');
    setLoading(true);

    try {
      const orderPayload = {
        userId: user?.userId || 1,
        items: cart.map((item) => ({
          productId: item.id,
          name: item.name,
          image: item.image,
          price: Number(item.price),
          quantity: item.quantity,
        })),
        totalAmount: getTotal(),
        paymentMethod: paymentMethod === 'card' ? 'Credit Card' : 'Cash on Delivery',
      };

      await api.post('/orders', orderPayload);

      clearCart();
      
      const successMessage = paymentMethod === 'card' 
        ? 'Payment successful! Your order has been placed.' 
        : 'Order placed successfully! You will pay on delivery.';
      
      alert(successMessage);
      navigate('/user-dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Payment failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (cart.length === 0) {
    return (
      <div style={pageStyle}>
        <header style={headerStyle}>
          <div style={headerContent}>
            <button style={backBtn} onClick={() => navigate('/cart')}>← Back</button>
            <h2 style={headerTitle}>Secure Checkout</h2>
            <div style={{ width: '80px' }} />
          </div>
        </header>
        <div style={emptyContainer}>
          <div style={emptyIcon}>🛒</div>
          <p style={emptyText}>Your cart is empty</p>
          <button style={shopBtn} onClick={() => navigate('/user-home')}>Continue Shopping</button>
        </div>
      </div>
    );
  }

  return (
    <div style={pageStyle}>
      {/* Header */}
      <header style={headerStyle}>
        <div style={headerContent}>
          <button style={backBtn} onClick={() => navigate('/cart')}>← Back to Cart</button>
          <div style={headerCenter}>
            <span style={stepActive}>Cart</span>
            <span style={stepArrow}>→</span>
            <span style={stepActive}>Payment</span>
            <span style={stepArrow}>→</span>
            <span style={stepInactive}>Confirmation</span>
          </div>
          <div style={secureBadge}>
            <span>🔒 Secure Payment</span>
          </div>
        </div>
      </header>

      <div style={paymentContainer}>
        {error && (
          <div style={errorBox}>
            <span style={errorIcon}>⚠️</span>
            <span>{error}</span>
            <button style={errorClose} onClick={() => setError('')}>×</button>
          </div>
        )}

        <div style={content}>
          {/* Order Summary */}
          <div style={summarySection}>
            <div style={summaryHeader}>
              <h3 style={summaryTitle}>Order Summary</h3>
              <span style={itemCount}>{cart.length} {cart.length === 1 ? 'item' : 'items'}</span>
            </div>
            
            <div style={itemsList}>
              {cart.map((item) => (
                <div key={item.id} style={summaryItem}>
                  <div style={itemInfo}>
                    <img src={item.image} alt={item.name} style={itemImage} />
                    <div>
                      <p style={itemNameStyle}>{item.name}</p>
                      <p style={itemQuantityStyle}>Quantity: {item.quantity}</p>
                    </div>
                  </div>
                  <p style={itemTotalStyle}>₹{(Number(item.price) * item.quantity).toLocaleString('en-IN')}</p>
                </div>
              ))}
            </div>
            
            <div style={summaryDivider} />
            
            <div style={priceBreakdown}>
              <div style={priceRow}>
                <span>Subtotal</span>
                <span>₹{getTotal().toLocaleString('en-IN')}</span>
              </div>
              <div style={priceRow}>
                <span>Shipping</span>
                <span style={freeShipping}>Free</span>
              </div>
              <div style={priceRow}>
                <span>Tax (GST)</span>
                <span>Included</span>
              </div>
            </div>
            
            <div style={totalRow}>
              <span style={totalLabel}>Total Amount</span>
              <span style={totalAmount}>₹{getTotal().toLocaleString('en-IN')}</span>
            </div>
            
            <div style={secureNote}>
              <span>🔒</span>
              <span>Your payment information is secure with us</span>
            </div>
          </div>

          {/* Payment Form */}
          <div style={formSection}>
            <div style={paymentMethodContainer}>
              <h3 style={formTitle}>Select Payment Method</h3>
              <div style={methodOptions}>
                <label style={methodLabel}>
                  <input
                    type="radio"
                    value="card"
                    checked={paymentMethod === 'card'}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    style={radioInput}
                  />
                  <div style={methodCard}>
                    <span>💳</span>
                    <span>Credit/Debit Card</span>
                  </div>
                </label>
                <label style={methodLabel}>
                  <input
                    type="radio"
                    value="cod"
                    checked={paymentMethod === 'cod'}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    style={radioInput}
                  />
                  <div style={methodCard}>
                    <span>💰</span>
                    <span>Cash on Delivery</span>
                  </div>
                </label>
              </div>
            </div>

            {paymentMethod === 'card' ? (
              <form onSubmit={handlePayment} style={form}>
                <div style={formGroup}>
                  <label style={labelStyle}>
                    <span>💳</span> Cardholder Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    placeholder="Enter name as on card"
                    value={paymentDetails.name}
                    onChange={handleChange}
                    style={inputStyle}
                    required
                  />
                </div>

                <div style={formGroup}>
                  <label style={labelStyle}>
                    <span>🔢</span> Card Number
                  </label>
                  <input
                    type="text"
                    name="cardNumber"
                    placeholder="1234 5678 9012 3456"
                    value={paymentDetails.cardNumber}
                    onChange={handleCardInput}
                    style={inputStyle}
                    maxLength="19"
                    required
                  />
                  <div style={cardIcons}>
                    <span>💳</span>
                    <span>💳</span>
                    <span>💳</span>
                  </div>
                </div>

                <div style={rowInputs}>
                  <div style={formGroup}>
                    <label style={labelStyle}>
                      <span>📅</span> Expiry Date
                    </label>
                    <input
                      type="text"
                      name="expiry"
                      placeholder="MM/YY"
                      value={paymentDetails.expiry}
                      onChange={handleCardInput}
                      style={inputStyle}
                      maxLength="5"
                      required
                    />
                    <small style={hintText}>Enter valid month (01-12) and year</small>
                  </div>
                  <div style={formGroup}>
                    <label style={labelStyle}>
                      <span>🔐</span> CVV
                    </label>
                    <input
                      type="password"
                      name="cvv"
                      placeholder="123"
                      value={paymentDetails.cvv}
                      onChange={handleChange}
                      style={inputStyle}
                      maxLength="4"
                      required
                    />
                  </div>
                </div>

                <button type="submit" disabled={loading} style={payBtn}>
                  {loading ? (
                    <span style={loadingSpinner}>
                      <span style={spinner}></span> Processing...
                    </span>
                  ) : (
                    'Pay ₹' + getTotal().toLocaleString('en-IN')
                  )}
                </button>
              </form>
            ) : (
              <div style={codContainer}>
                <div style={codIcon}>💰</div>
                <h4 style={codTitle}>Cash on Delivery</h4>
                <p style={codDescription}>
                  Pay when you receive your order. No advance payment required.
                </p>
                <button 
                  onClick={handlePayment} 
                  disabled={loading} 
                  style={codPayBtn}
                >
                  {loading ? (
                    <span>Processing...</span>
                  ) : (
                    'Place Order (Pay on Delivery)'
                  )}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

/* ======= Professional Styles ======= */
const pageStyle = {
  fontFamily: "'Inter', 'Poppins', sans-serif",
  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
  minHeight: '100vh',
  paddingBottom: '50px'
};

const headerStyle = {
  backgroundColor: 'white',
  padding: '20px 0',
  boxShadow: '0 2px 20px rgba(0,0,0,0.1)',
  marginBottom: '30px'
};

const headerContent = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  maxWidth: '1200px',
  margin: '0 auto',
  padding: '0 20px'
};

const backBtn = {
  background: 'none',
  border: 'none',
  fontSize: '15px',
  cursor: 'pointer',
  color: '#667eea',
  fontWeight: '600',
  padding: '10px 20px',
  borderRadius: '8px',
  transition: 'all 0.3s',
  fontFamily: 'inherit'
};

const headerCenter = {
  display: 'flex',
  alignItems: 'center',
  gap: '15px'
};

const stepActive = {
  color: '#667eea',
  fontWeight: '600',
  fontSize: '14px'
};

const stepInactive = {
  color: '#ccc',
  fontWeight: '600',
  fontSize: '14px'
};

const stepArrow = {
  color: '#ddd',
  fontSize: '14px'
};

const secureBadge = {
  backgroundColor: '#f0f0f0',
  padding: '8px 15px',
  borderRadius: '20px',
  fontSize: '13px',
  fontWeight: '600',
  color: '#333'
};

const headerTitle = {
  fontSize: '24px',
  fontWeight: 'bold',
  background: 'linear-gradient(135deg, #667eea, #764ba2)',
  WebkitBackgroundClip: 'text',
  WebkitTextFillColor: 'transparent',
  margin: 0
};

const paymentContainer = {
  maxWidth: '1200px',
  margin: '0 auto',
  padding: '0 20px'
};

const emptyContainer = {
  maxWidth: '500px',
  margin: '100px auto',
  textAlign: 'center',
  backgroundColor: 'white',
  padding: '60px',
  borderRadius: '20px',
  boxShadow: '0 10px 40px rgba(0,0,0,0.1)'
};

const emptyIcon = {
  fontSize: '80px',
  marginBottom: '20px'
};

const emptyText = {
  fontSize: '20px',
  color: '#666',
  marginBottom: '30px'
};

const shopBtn = {
  background: 'linear-gradient(135deg, #667eea, #764ba2)',
  color: 'white',
  border: 'none',
  padding: '12px 30px',
  borderRadius: '25px',
  fontSize: '16px',
  fontWeight: '600',
  cursor: 'pointer'
};

const errorBox = {
  background: '#fee',
  color: '#c00',
  padding: '15px 20px',
  borderRadius: '12px',
  marginBottom: '20px',
  display: 'flex',
  alignItems: 'center',
  gap: '10px',
  justifyContent: 'space-between'
};

const errorIcon = {
  fontSize: '20px'
};

const errorClose = {
  background: 'none',
  border: 'none',
  fontSize: '24px',
  cursor: 'pointer',
  color: '#c00'
};

const content = {
  display: 'grid',
  gridTemplateColumns: '1fr 1.2fr',
  gap: '30px'
};

const summarySection = {
  backgroundColor: 'white',
  borderRadius: '20px',
  padding: '30px',
  boxShadow: '0 10px 40px rgba(0,0,0,0.1)',
  position: 'sticky',
  top: '20px',
  height: 'fit-content'
};

const summaryHeader = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: '25px'
};

const summaryTitle = {
  fontSize: '22px',
  fontWeight: 'bold',
  background: 'linear-gradient(135deg, #667eea, #764ba2)',
  WebkitBackgroundClip: 'text',
  WebkitTextFillColor: 'transparent',
  margin: 0
};

const itemCount = {
  color: '#666',
  fontSize: '14px',
  fontWeight: '500'
};

const itemsList = {
  maxHeight: '400px',
  overflowY: 'auto',
  marginBottom: '20px'
};

const summaryItem = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '15px 0',
  borderBottom: '1px solid #f0f0f0'
};

const itemInfo = {
  display: 'flex',
  alignItems: 'center',
  gap: '15px',
  flex: 1
};

const itemImage = {
  width: '50px',
  height: '50px',
  objectFit: 'cover',
  borderRadius: '10px'
};

const itemNameStyle = {
  fontSize: '15px',
  fontWeight: '600',
  color: '#333',
  margin: '0 0 5px'
};

const itemQuantityStyle = {
  fontSize: '13px',
  color: '#666',
  margin: 0
};

const itemTotalStyle = {
  fontSize: '16px',
  fontWeight: 'bold',
  color: '#667eea',
  margin: 0
};

const summaryDivider = {
  height: '2px',
  background: 'linear-gradient(90deg, #667eea, #764ba2)',
  margin: '20px 0'
};

const priceBreakdown = {
  marginBottom: '20px'
};

const priceRow = {
  display: 'flex',
  justifyContent: 'space-between',
  padding: '8px 0',
  color: '#666',
  fontSize: '14px'
};

const freeShipping = {
  color: '#4caf50',
  fontWeight: '600'
};

const totalRow = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  paddingTop: '15px',
  borderTop: '2px solid #f0f0f0'
};

const totalLabel = {
  fontSize: '18px',
  fontWeight: 'bold',
  color: '#333'
};

const totalAmount = {
  fontSize: '28px',
  fontWeight: 'bold',
  background: 'linear-gradient(135deg, #667eea, #764ba2)',
  WebkitBackgroundClip: 'text',
  WebkitTextFillColor: 'transparent'
};

const secureNote = {
  marginTop: '20px',
  padding: '12px',
  backgroundColor: '#f9f9f9',
  borderRadius: '10px',
  display: 'flex',
  alignItems: 'center',
  gap: '10px',
  fontSize: '12px',
  color: '#666',
  justifyContent: 'center'
};

const formSection = {
  backgroundColor: 'white',
  borderRadius: '20px',
  padding: '30px',
  boxShadow: '0 10px 40px rgba(0,0,0,0.1)'
};

const paymentMethodContainer = {
  marginBottom: '30px'
};

const formTitle = {
  fontSize: '20px',
  fontWeight: 'bold',
  color: '#333',
  marginBottom: '20px'
};

const methodOptions = {
  display: 'flex',
  gap: '15px'
};

const methodLabel = {
  flex: 1,
  cursor: 'pointer'
};

const radioInput = {
  display: 'none'
};

const methodCard = {
  padding: '15px',
  border: '2px solid #e0e0e0',
  borderRadius: '12px',
  display: 'flex',
  alignItems: 'center',
  gap: '10px',
  transition: 'all 0.3s',
  cursor: 'pointer'
};

const form = {
  display: 'flex',
  flexDirection: 'column',
  gap: '20px'
};

const formGroup = {
  display: 'flex',
  flexDirection: 'column',
  gap: '8px'
};

const labelStyle = {
  fontSize: '13px',
  fontWeight: '600',
  color: '#555',
  textTransform: 'uppercase',
  letterSpacing: '0.5px',
  display: 'flex',
  alignItems: 'center',
  gap: '5px'
};

const inputStyle = {
  padding: '12px 15px',
  border: '2px solid #e0e0e0',
  borderRadius: '10px',
  fontSize: '14px',
  outline: 'none',
  transition: 'all 0.3s',
  fontFamily: 'inherit'
};

const hintText = {
  fontSize: '11px',
  color: '#999',
  marginTop: '4px'
};

const rowInputs = {
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  gap: '15px'
};

const cardIcons = {
  display: 'flex',
  gap: '8px',
  marginTop: '5px',
  fontSize: '20px'
};

const payBtn = {
  background: 'linear-gradient(135deg, #667eea, #764ba2)',
  color: 'white',
  border: 'none',
  padding: '15px',
  borderRadius: '12px',
  fontSize: '16px',
  fontWeight: 'bold',
  cursor: 'pointer',
  marginTop: '10px',
  transition: 'transform 0.3s, box-shadow 0.3s'
};

const codContainer = {
  textAlign: 'center',
  padding: '40px 20px'
};

const codIcon = {
  fontSize: '60px',
  marginBottom: '20px'
};

const codTitle = {
  fontSize: '22px',
  color: '#333',
  marginBottom: '10px'
};

const codDescription = {
  color: '#666',
  marginBottom: '30px',
  lineHeight: '1.6'
};

const codPayBtn = {
  background: 'linear-gradient(135deg, #667eea, #764ba2)',
  color: 'white',
  border: 'none',
  padding: '14px 30px',
  borderRadius: '12px',
  fontSize: '16px',
  fontWeight: 'bold',
  cursor: 'pointer'
};

const loadingSpinner = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: '10px'
};

const spinner = {
  width: '16px',
  height: '16px',
  border: '2px solid white',
  borderTopColor: 'transparent',
  borderRadius: '50%',
  animation: 'spin 0.6s linear infinite'
};

// Add CSS animation
const style = document.createElement('style');
style.textContent = `
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
  
  input:focus {
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
  }
  
  button:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
  }
  
  button:active:not(:disabled) {
    transform: translateY(0);
  }
  
  ${methodLabel}:has(input:checked) ${methodCard} {
    border-color: #667eea;
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.05), rgba(118, 75, 162, 0.05));
  }
  
  .summaryItem:hover {
    background-color: #f9f9f9;
  }
`;
document.head.appendChild(style);

export default Payment;