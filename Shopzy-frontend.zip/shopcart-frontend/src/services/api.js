import axios from 'axios';

/**
 * Centralized Axios instance for ShopCart backend API.
 * All requests go to http://localhost:8089/api
 * Session token is automatically attached from localStorage.
 */
const api = axios.create({
  baseURL: 'http://localhost:8089/api',
  headers: { 'Content-Type': 'application/json' },
});

// ── Request Interceptor ──────────────────────────────────────────────────────
// Automatically attach session token to every request
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('sessionToken');
    if (token) {
      config.headers['X-Session-Token'] = token;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// ── Response Interceptor ─────────────────────────────────────────────────────
// Handle 401 globally (session expired → redirect to login)
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.clear();
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;
