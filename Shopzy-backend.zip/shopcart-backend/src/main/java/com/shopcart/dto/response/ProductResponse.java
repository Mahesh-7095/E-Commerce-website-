package com.shopcart.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO for sending Product data in API responses.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductResponse {

    private Long id;
    private String name;
    private String image;
    private BigDecimal price;
    private Integer quantity;
    private String discount;
    private Long categoryId;
    private String category;
    private LocalDateTime createdAt;
}
