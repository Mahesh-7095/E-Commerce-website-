package com.shopcart.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

/**
 * DTO returned after a successful login.
 * Contains the authenticated user's profile and assigned role.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LoginResponse {

    private Long userId;
    private String fullName;
    private String email;
    private String role;
    private String sessionToken;
}
