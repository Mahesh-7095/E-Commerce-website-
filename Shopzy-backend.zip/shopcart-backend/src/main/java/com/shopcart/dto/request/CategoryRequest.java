package com.shopcart.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;

/**
 * DTO for creating or updating a Category.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CategoryRequest {

    @NotBlank(message = "Category name is required")
    @Size(min = 2, max = 100)
    private String name;

    private String discount;
}
