package com.shopcart.util;

import org.springframework.stereotype.Component;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * SessionUtil
 *
 * Provides lightweight session token management without Spring Security.
 * Generates cryptographically secure tokens and maintains an in-memory
 * token-to-userId mapping for simple authentication verification.
 *
 * Note: For production, replace this with a persistent store (Redis / DB).
 */
@Component
public class SessionUtil {

    private static final int TOKEN_BYTE_LENGTH = 32;

    /**
     * In-memory session store: token → userId
     * ConcurrentHashMap ensures thread-safe access.
     */
    private final Map<String, Long> activeSessions = new ConcurrentHashMap<>();

    /**
     * Generates a new secure random session token and registers it
     * against the provided userId.
     *
     * @param userId the ID of the authenticated user
     * @return a URL-safe Base64-encoded session token
     */
    public String createSession(Long userId) {
        byte[] tokenBytes = new byte[TOKEN_BYTE_LENGTH];
        new SecureRandom().nextBytes(tokenBytes);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(tokenBytes);

        activeSessions.put(token, userId);
        return token;
    }

    /**
     * Resolves a session token to the authenticated userId.
     *
     * @param token the session token from the request header
     * @return the userId associated with the token, or null if invalid/expired
     */
    public Long getUserIdFromToken(String token) {
        if (token == null || token.isBlank()) {
            return null;
        }
        return activeSessions.get(token);
    }

    /**
     * Checks whether a given session token is currently active.
     *
     * @param token the session token to validate
     * @return true if the token maps to an active session
     */
    public boolean isValidSession(String token) {
        return token != null && activeSessions.containsKey(token);
    }

    /**
     * Invalidates a session token, effectively logging out the user.
     *
     * @param token the session token to invalidate
     */
    public void invalidateSession(String token) {
        if (token != null) {
            activeSessions.remove(token);
        }
    }
}
