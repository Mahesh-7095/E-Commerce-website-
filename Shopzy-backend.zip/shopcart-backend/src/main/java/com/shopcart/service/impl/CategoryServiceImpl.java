package com.shopcart.service.impl;

import com.shopcart.dto.request.CategoryRequest;
import com.shopcart.dto.response.CategoryResponse;
import com.shopcart.dto.response.ProductResponse;
import com.shopcart.exception.DuplicateResourceException;
import com.shopcart.exception.ResourceNotFoundException;
import com.shopcart.model.Category;
import com.shopcart.model.Product;
import com.shopcart.repository.CategoryRepository;
import com.shopcart.service.CategoryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * CategoryServiceImpl
 *
 * Implements the {@link CategoryService} interface, handling all business logic
 * related to product category management in the ShopCart Admin Dashboard.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepository categoryRepository;

    /** {@inheritDoc} */
    @Override
    @Transactional(readOnly = true)
    public List<CategoryResponse> getAllCategories() {
        log.debug("Fetching all categories.");
        return categoryRepository.findAll()
                .stream()
                .map(this::mapToCategoryResponse)
                .collect(Collectors.toList());
    }

    /** {@inheritDoc} */
    @Override
    @Transactional(readOnly = true)
    public CategoryResponse getCategoryById(Long id) {
        log.debug("Fetching category with ID: {}", id);
        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", id));
        return mapToCategoryResponseWithProducts(category);
    }

    /** {@inheritDoc} */
    @Override
    @Transactional
    public CategoryResponse createCategory(CategoryRequest request) {
        log.info("Creating new category: {}", request.getName());

        if (categoryRepository.existsByNameIgnoreCase(request.getName())) {
            throw new DuplicateResourceException(
                    "Category with name '" + request.getName() + "' already exists."
            );
        }

        Category category = Category.builder()
                .name(request.getName())
                .sold(0)
                .build();

        Category saved = categoryRepository.save(category);
        log.info("Category created with ID: {}", saved.getId());

        return mapToCategoryResponse(saved);
    }

    /** {@inheritDoc} */
    @Override
    @Transactional
    public CategoryResponse updateCategory(Long id, CategoryRequest request) {
        log.info("Updating category with ID: {}", id);

        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", id));

        // Check for name conflict only if the name is actually changing
        if (!category.getName().equalsIgnoreCase(request.getName())
                && categoryRepository.existsByNameIgnoreCase(request.getName())) {
            throw new DuplicateResourceException(
                    "Category with name '" + request.getName() + "' already exists."
            );
        }

        category.setName(request.getName());

        Category updated = categoryRepository.save(category);
        log.info("Category updated: ID {}", updated.getId());

        return mapToCategoryResponseWithProducts(updated);
    }

    /** {@inheritDoc} */
    @Override
    @Transactional
    public void deleteCategory(Long id) {
        log.info("Deleting category with ID: {}", id);

        if (!categoryRepository.existsById(id)) {
            throw new ResourceNotFoundException("Category", "id", id);
        }

        categoryRepository.deleteById(id);
        log.info("Category deleted: ID {}", id);
    }

    /** {@inheritDoc} */
    @Override
    @Transactional
    public CategoryResponse updateDiscount(Long id, String discount) {
        log.info("Updating discount for category ID: {} to {}", id, discount);

        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", id));

        
        Category updated = categoryRepository.save(category);

        return mapToCategoryResponseWithProducts(updated);
    }

    // ── Private mappers ────────────────────────────────────────────────────

    private CategoryResponse mapToCategoryResponse(Category category) {
        return CategoryResponse.builder()
                .id(category.getId())
                .name(category.getName())
                .sold(category.getSold())
                .totalProducts(
                        category.getProducts() != null ? category.getProducts().size() : 0
                )
                .build();
    }

    private CategoryResponse mapToCategoryResponseWithProducts(Category category) {
        List<ProductResponse> productResponses = category.getProducts() != null
                ? category.getProducts().stream()
                        .map(this::mapToProductResponse)
                        .collect(Collectors.toList())
                : Collections.emptyList();

        return CategoryResponse.builder()
                .id(category.getId())
                .name(category.getName())
                .sold(category.getSold())
                .totalProducts(productResponses.size())
                .products(productResponses)
                .build();
    }

    private ProductResponse mapToProductResponse(Product product) {
        return ProductResponse.builder()
                .id(product.getId())
                .name(product.getName())
                .image(product.getImageUrl())
                .price(product.getPrice())
                .quantity(product.getQuantity())
                .discount(product.getDiscount())
                .categoryId(product.getCategory().getId())
                .category(product.getCategory().getName())
                .build();
    }
}
