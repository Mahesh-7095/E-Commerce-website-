//package com.shopcart.service.impl;
//
//import com.shopcart.dto.request.OrderRequest;
//import com.shopcart.dto.response.OrderResponse;
//import com.shopcart.exception.ResourceNotFoundException;
//import com.shopcart.model.Order;
//import com.shopcart.model.OrderItem;
//import com.shopcart.model.User;
//import com.shopcart.repository.OrderRepository;
//import com.shopcart.repository.UserRepository;
//import com.shopcart.service.OrderService;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import java.math.BigDecimal;
//import java.util.List;
//import java.util.stream.Collectors;
//
///**
// * OrderServiceImpl
// *
// * Implements the {@link OrderService} interface, handling all business logic
// * for order placement, retrieval, and status management.
// */
//@Slf4j
//@Service
//@RequiredArgsConstructor
//public class OrderServiceImpl implements OrderService {
//
//    private final OrderRepository orderRepository;
//    private final UserRepository userRepository;
//
//    /** {@inheritDoc} */
//    @Override
//    @Transactional
//    public OrderResponse placeOrder(OrderRequest request) {
//        log.info("Placing order for user ID: {}", request.getUserId());
//
//        User user = userRepository.findById(request.getUserId())
//                .orElseThrow(() -> new ResourceNotFoundException("User", "id", request.getUserId()));
//
//        // Build the Order entity
//        Order order = Order.builder()
//                .user(user)
//                .totalAmount(request.getTotalAmount())
//                .paymentMethod(request.getPaymentMethod())
//                .status(Order.OrderStatus.PROCESSING)
//                .build();
//
//        // Map each cart item from the request into an OrderItem entity
//        List<OrderItem> orderItems = request.getItems().stream()
//                .map(itemRequest -> {
//                    BigDecimal subtotal = itemRequest.getPrice()
//                            .multiply(BigDecimal.valueOf(itemRequest.getQuantity()));
//
//                    return OrderItem.builder()
//                            .order(order)
//                            .productId(itemRequest.getProductId())
//                            .productName(itemRequest.getName())
//                            .productImage(itemRequest.getImage())
//                            .unitPrice(itemRequest.getPrice())
//                            .quantity(itemRequest.getQuantity())
//                            .subtotal(subtotal)
//                            .build();
//                })
//                .collect(Collectors.toList());
//
//        order.setOrderItems(orderItems);
//
//        Order savedOrder = orderRepository.save(order);
//        log.info("Order placed successfully with ID: {}", savedOrder.getId());
//
//        return mapToOrderResponse(savedOrder);
//    }
//
//    /** {@inheritDoc} */
//    @Override
//    @Transactional(readOnly = true)
//    public List<OrderResponse> getOrdersByUser(Long userId) {
//        log.debug("Fetching orders for user ID: {}", userId);
//
//        if (!userRepository.existsById(userId)) {
//            throw new ResourceNotFoundException("User", "id", userId);
//        }
//
//        return orderRepository.findByUserIdOrderByOrderedAtDesc(userId)
//                .stream()
//                .map(this::mapToOrderResponse)
//                .collect(Collectors.toList());
//    }
//
//    /** {@inheritDoc} */
//    @Override
//    @Transactional(readOnly = true)
//    public OrderResponse getOrderById(Long orderId) {
//        log.debug("Fetching order with ID: {}", orderId);
//
//        Order order = orderRepository.findById(orderId)
//                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", orderId));
//
//        return mapToOrderResponse(order);
//    }
//
//    /** {@inheritDoc} */
//    @Override
//    @Transactional(readOnly = true)
//    public List<OrderResponse> getAllOrders() {
//        log.debug("Fetching all orders (Admin request).");
//
//        return orderRepository.findAll()
//                .stream()
//                .map(this::mapToOrderResponse)
//                .collect(Collectors.toList());
//    }
//
//    /** {@inheritDoc} */
//    @Override
//    @Transactional
//    public OrderResponse updateOrderStatus(Long orderId, Order.OrderStatus status) {
//        log.info("Updating order ID: {} to status: {}", orderId, status);
//
//        Order order = orderRepository.findById(orderId)
//                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", orderId));
//
//        order.setStatus(status);
//        Order updated = orderRepository.save(order);
//
//        log.info("Order ID {} status updated to {}", orderId, status);
//        return mapToOrderResponse(updated);
//    }
//
//    // ── Private mapper ─────────────────────────────────────────────────────
//
//    private OrderResponse mapToOrderResponse(Order order) {
//        List<OrderResponse.OrderItemResponse> itemResponses = order.getOrderItems()
//                .stream()
//                .map(item -> OrderResponse.OrderItemResponse.builder()
//                        .id(item.getId())
//                        .productId(item.getProductId())
//                        .name(item.getProductName())
//                        .image(item.getProductImage())
//                        .unitPrice(item.getUnitPrice())
//                        .quantity(item.getQuantity())
//                        .subtotal(item.getSubtotal())
//                        .build())
//                .collect(Collectors.toList());
//
//        return OrderResponse.builder()
//                .id(order.getId())
//                .userId(order.getUser().getId())
//                .userName(order.getUser().getFullName())
//                .totalAmount(order.getTotalAmount())
//                .status(order.getStatus().name())
//                .paymentMethod(order.getPaymentMethod())
//                .orderedAt(order.getOrderedAt())
//                .items(itemResponses)
//                .build();
//    }
//}


package com.shopcart.service.impl;

import com.shopcart.dto.request.OrderRequest;
import com.shopcart.dto.response.OrderResponse;
import com.shopcart.exception.ResourceNotFoundException;
import com.shopcart.model.Order;
import com.shopcart.model.OrderItem;
import com.shopcart.model.Product;
import com.shopcart.model.User;
import com.shopcart.repository.OrderRepository;
import com.shopcart.repository.ProductRepository;
import com.shopcart.repository.UserRepository;
import com.shopcart.service.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

/**
 * OrderServiceImpl
 *
 * Implements the {@link OrderService} interface, handling all business logic
 * for order placement, retrieval, and status management.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final UserRepository userRepository;
    private final ProductRepository productRepository;

    /** {@inheritDoc} */
    @Override
    @Transactional
    public OrderResponse placeOrder(OrderRequest request) {
        log.info("Placing order for user ID: {}", request.getUserId());

        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", request.getUserId()));

        // Build the Order entity
        Order order = Order.builder()
                .user(user)
                .totalAmount(request.getTotalAmount())
                .paymentMethod(request.getPaymentMethod())
                .status(Order.OrderStatus.PROCESSING)
                .build();

        // Map each cart item from the request into an OrderItem entity
        List<OrderItem> orderItems = request.getItems().stream()
                .map(itemRequest -> {
                    BigDecimal subtotal = itemRequest.getPrice()
                            .multiply(BigDecimal.valueOf(itemRequest.getQuantity()));

                    return OrderItem.builder()
                            .order(order)
                            .productId(itemRequest.getProductId())
                            .productName(itemRequest.getName())
                            .productImage(itemRequest.getImage())
                            .unitPrice(itemRequest.getPrice())
                            .quantity(itemRequest.getQuantity())
                            .subtotal(subtotal)
                            .build();
                })
                .collect(Collectors.toList());

        order.setOrderItems(orderItems);

        Order savedOrder = orderRepository.save(order);
        log.info("Order placed successfully with ID: {}", savedOrder.getId());

        return mapToOrderResponse(savedOrder);
    }

    /** {@inheritDoc} */
    @Override
    @Transactional(readOnly = true)
    public List<OrderResponse> getOrdersByUser(Long userId) {
        log.debug("Fetching orders for user ID: {}", userId);

        if (!userRepository.existsById(userId)) {
            throw new ResourceNotFoundException("User", "id", userId);
        }

        return orderRepository.findByUserIdOrderByOrderedAtDesc(userId)
                .stream()
                .map(this::mapToOrderResponse)
                .collect(Collectors.toList());
    }

    /** {@inheritDoc} */
    @Override
    @Transactional(readOnly = true)
    public OrderResponse getOrderById(Long orderId) {
        log.debug("Fetching order with ID: {}", orderId);

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", orderId));

        return mapToOrderResponse(order);
    }

    /** {@inheritDoc} */
    @Override
    @Transactional(readOnly = true)
    public List<OrderResponse> getAllOrders() {
        log.debug("Fetching all orders (Admin request).");

        return orderRepository.findAll()
                .stream()
                .map(this::mapToOrderResponse)
                .collect(Collectors.toList());
    }

    /** {@inheritDoc} */
    @Override
    @Transactional
    public OrderResponse updateOrderStatus(Long orderId, Order.OrderStatus status) {
        log.info("Updating order ID: {} to status: {}", orderId, status);

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", orderId));

        Order.OrderStatus previousStatus = order.getStatus();
        order.setStatus(status);
        Order updated = orderRepository.save(order);

        // ── Reduce product stock when order is marked DELIVERED ──────────────
        // Only deduct once: if previous status was NOT already DELIVERED/CANCELLED
        if (status == Order.OrderStatus.DELIVERED
                && previousStatus != Order.OrderStatus.DELIVERED
                && previousStatus != Order.OrderStatus.CANCELLED) {

            for (OrderItem item : order.getOrderItems()) {
                if (item.getProductId() != null) {
                    productRepository.findById(item.getProductId()).ifPresent(product -> {
                        int newQty = Math.max(0, product.getQuantity() - item.getQuantity());
                        product.setQuantity(newQty);
                        productRepository.save(product);
                        log.info("Reduced product ID {} quantity by {} → new qty: {}",
                                product.getId(), item.getQuantity(), newQty);
                    });
                }
            }
        }

        log.info("Order ID {} status updated to {}", orderId, status);
        return mapToOrderResponse(updated);
    }

    // ── Private mapper ─────────────────────────────────────────────────────

    private OrderResponse mapToOrderResponse(Order order) {
        List<OrderResponse.OrderItemResponse> itemResponses = order.getOrderItems()
                .stream()
                .map(item -> OrderResponse.OrderItemResponse.builder()
                        .id(item.getId())
                        .productId(item.getProductId())
                        .name(item.getProductName())
                        .image(item.getProductImage())
                        .unitPrice(item.getUnitPrice())
                        .quantity(item.getQuantity())
                        .subtotal(item.getSubtotal())
                        .build())
                .collect(Collectors.toList());

        return OrderResponse.builder()
                .id(order.getId())
                .userId(order.getUser().getId())
                .userName(order.getUser().getFullName())
                .totalAmount(order.getTotalAmount())
                .status(order.getStatus().name())
                .paymentMethod(order.getPaymentMethod())
                .orderedAt(order.getOrderedAt())
                .items(itemResponses)
                .build();
    }
}