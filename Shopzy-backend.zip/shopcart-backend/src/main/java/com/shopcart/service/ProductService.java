package com.shopcart.service;

import com.shopcart.dto.request.ProductRequest;
import com.shopcart.dto.response.ProductResponse;

import java.util.List;

/**
 * ProductService
 *
 * Defines the business operations available for Products in the ShopCart platform.
 */
public interface ProductService {

    /** Retrieves all products in the catalog. */
    List<ProductResponse> getAllProducts();

    /** Retrieves a single product by its ID. */
    ProductResponse getProductById(Long id);

    /** Retrieves all products belonging to a specific category. */
    List<ProductResponse> getProductsByCategory(Long categoryId);

    /** Searches products by keyword (name or category). */
    List<ProductResponse> searchProducts(String keyword);

    /** Creates a new product under a given category. */
    ProductResponse createProduct(ProductRequest request);

    /** Updates an existing product's details. */
    ProductResponse updateProduct(Long id, ProductRequest request);

    /** Deletes a product by its ID. */
    void deleteProduct(Long id);
}
