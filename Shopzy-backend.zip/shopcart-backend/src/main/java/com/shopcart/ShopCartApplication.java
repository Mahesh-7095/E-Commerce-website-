package com.shopcart;

import java.util.TimeZone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * ShopCart Backend Application
 *
 * Entry point for the ShopCart E-Commerce REST API.
 * Built using Spring Boot 3.x with JPA, MySQL, and a clean layered architecture.
 *
 * @author ShopCart Team
 * @version 1.0.0
 */
@SpringBootApplication
public class ShopCartApplication {

    public static void main(String[] args) {
    		SpringApplication.run(ShopCartApplication.class, args);
    }
}
