package com.shopcart.repository;

import com.shopcart.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * CategoryRepository
 *
 * Provides data access operations for the {@link Category} entity.
 */
@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {

    /**
     * Checks whether a category with the given name already exists.
     * Used to prevent duplicate category creation.
     */
    boolean existsByNameIgnoreCase(String name);

    /**
     * Finds a category by its exact name (case-insensitive).
     */
    Optional<Category> findByNameIgnoreCase(String name);
}
