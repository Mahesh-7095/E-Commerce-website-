package com.shopcart.repository;

import com.shopcart.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * ProductRepository
 *
 * Provides data access operations for the {@link Product} entity.
 */
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    /**
     * Fetches all products belonging to the specified category.
     */
    List<Product> findByCategoryId(Long categoryId);

    /**
     * Fetches all products belonging to the specified category name (case-insensitive).
     */
    @Query("SELECT p FROM Product p WHERE LOWER(p.category.name) = LOWER(:categoryName)")
    List<Product> findByCategoryNameIgnoreCase(@Param("categoryName") String categoryName);

    /**
     * Full-text product search across name and category name.
     */
    @Query("SELECT p FROM Product p WHERE " +
           "LOWER(p.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(p.category.name) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Product> searchByKeyword(@Param("keyword") String keyword);

    /**
     * Counts the number of products under a given category.
     */
    long countByCategoryId(Long categoryId);
}
