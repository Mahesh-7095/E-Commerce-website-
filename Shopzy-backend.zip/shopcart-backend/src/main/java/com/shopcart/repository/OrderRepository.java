package com.shopcart.repository;

import com.shopcart.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

/**
 * OrderRepository
 *
 * Provides data access operations for the {@link Order} entity.
 */
@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    /**
     * Retrieves all orders placed by a specific user, sorted newest first.
     */
    List<Order> findByUserIdOrderByOrderedAtDesc(Long userId);

    /**
     * Retrieves all orders with a specific status.
     */
    List<Order> findByStatusOrderByOrderedAtDesc(Order.OrderStatus status);

    /**
     * Calculates the total revenue across all delivered orders.
     */
    @Query("SELECT COALESCE(SUM(o.totalAmount), 0) FROM Order o WHERE o.status = 'DELIVERED'")
    BigDecimal calculateTotalRevenue();

    /**
     * Counts the number of orders placed by a specific user.
     */
    long countByUserId(Long userId);
}
