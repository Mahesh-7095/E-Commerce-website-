package com.shopcart.controller;

import com.shopcart.dto.request.SignupRequest;
import com.shopcart.dto.response.ApiResponse;
import com.shopcart.dto.response.UserResponse;
import com.shopcart.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * UserController
 *
 * Exposes REST endpoints for user profile management:
 *
 *   GET    /api/users                    — get all users (Admin)
 *   GET    /api/users/{id}               — get a user's profile
 *   PUT    /api/users/{id}/profile       — update name, phone (User: My Account tab)
 *   PATCH  /api/users/{id}/address       — update address fields (User: Address tab)
 *   PATCH  /api/users/{id}/password      — change password (User: Change Password tab)
 *   DELETE /api/users/{id}               — delete a user account (Admin)
 */
@Slf4j
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    // ── GET /api/users ─────────────────────────────────────────────────────

    /**
     * Returns a list of all registered users.
     * Intended for Admin Dashboard user management.
     */
    @GetMapping
    public ResponseEntity<ApiResponse<List<UserResponse>>> getAllUsers() {
        log.debug("Admin request to fetch all users.");
        List<UserResponse> users = userService.getAllUsers();
        return ResponseEntity.ok(
                ApiResponse.success("Users fetched successfully.", users)
        );
    }

    // ── GET /api/users/{id} ────────────────────────────────────────────────

    /**
     * Returns the full profile of a single user by their ID.
     * Called by UserDashboard.js to pre-populate the "My Account" form.
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<UserResponse>> getUserById(
            @PathVariable Long id) {

        log.debug("Fetching profile for user ID: {}", id);
        UserResponse user = userService.getUserById(id);
        return ResponseEntity.ok(
                ApiResponse.success("User profile fetched successfully.", user)
        );
    }

    // ── PUT /api/users/{id}/profile ────────────────────────────────────────

    /**
     * Updates a user's personal details (full name and phone number).
     * Called from the "My Account" tab in UserDashboard.js when
     * the user clicks the "Change" button.
     */
    @PutMapping("/{id}/profile")
    public ResponseEntity<ApiResponse<UserResponse>> updateProfile(
            @PathVariable Long id,
            @Valid @RequestBody SignupRequest request) {

        log.info("Profile update request for user ID: {}", id);
        UserResponse updated = userService.updateProfile(id, request);
        return ResponseEntity.ok(
                ApiResponse.success("Profile updated successfully.", updated)
        );
    }

    // ── PATCH /api/users/{id}/address ──────────────────────────────────────

    /**
     * Updates address-related fields for a user.
     * Called from the "Address" tab in UserDashboard.js.
     *
     * Request body: { "address": "...", "city": "...", "state": "...", "zipCode": "..." }
     */
    @PatchMapping("/{id}/address")
    public ResponseEntity<ApiResponse<UserResponse>> updateAddress(
            @PathVariable Long id,
            @RequestBody Map<String, String> addressFields) {

        log.info("Address update request for user ID: {}", id);
        UserResponse updated = userService.updateAddress(id, addressFields);
        return ResponseEntity.ok(
                ApiResponse.success("Address updated successfully.", updated)
        );
    }

    // ── PATCH /api/users/{id}/password ─────────────────────────────────────

    /**
     * Changes a user's password after verifying the current one.
     * Called from the "Change Password" tab in UserDashboard.js.
     *
     * Request body: { "currentPassword": "...", "newPassword": "..." }
     */
    @PatchMapping("/{id}/password")
    public ResponseEntity<ApiResponse<Void>> changePassword(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {

        log.info("Password change request for user ID: {}", id);

        String currentPassword = body.get("currentPassword");
        String newPassword     = body.get("newPassword");

        userService.changePassword(id, currentPassword, newPassword);

        return ResponseEntity.ok(
                ApiResponse.success("Password changed successfully.")
        );
    }

    // ── DELETE /api/users/{id} ─────────────────────────────────────────────

    /**
     * Permanently deletes a user account.
     * Admin-only operation.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteUser(
            @PathVariable Long id) {

        log.info("Admin request to delete user ID: {}", id);
        userService.deleteUser(id);
        return ResponseEntity.ok(
                ApiResponse.success("User account deleted successfully.")
        );
    }
}
